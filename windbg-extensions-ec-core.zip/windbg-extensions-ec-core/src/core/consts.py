"""
The constants.
"""
EC = "ec"

WINDBG_EXT_EC = f"!{EC}"

# the prefix of EC command file, e.g., cmd_basic.py
EC_CMD_PREFIX = "cmd_"
