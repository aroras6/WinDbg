"""
It defines the colors in Windbg.

See https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/customizing-debugger-output-using-dml
"""
NORMAL = ("normfg", "normbg")
RED = ("srcchar", "wbg")
BLUE = ("srcdrct", "wbg")
DARK_RED = ("changed", "wbg")
GREEN = ("srccmnt", "wbg")
PURPLE = ("srcannot", "wbg")
HIGHLIGHT = ("clfg", "clfg")


def normal(content: object) -> str:
    return colorize(NORMAL, content)


def highlight(content: object) -> str:
    return colorize(HIGHLIGHT, content)


def red(content: object) -> str:
    return colorize(RED, content)


def blue(content: object) -> str:
    return colorize(BLUE, content)


def dark_red(content: object) -> str:
    return colorize(DARK_RED, content)


def green(content: object) -> str:
    return colorize(GREEN, content)


def purple(content: object) -> str:
    return colorize(PURPLE, content)


def colorize(col: tuple, content: object) -> str:
    return '<col fg="{}" bg="{}">{}</col>'.format(col[0], col[1], content)
