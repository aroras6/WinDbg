"""
The exceptions.
"""


class CmdExecError(Exception):
    def __init__(self, errmsg):
        self.errmsg = errmsg
