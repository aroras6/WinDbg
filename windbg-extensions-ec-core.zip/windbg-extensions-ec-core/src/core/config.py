"""
The configurations.
"""

# Global verbose flag. This configuration enables EC verboses. For each command verbose, set 'verbose_cmd'.
verbose = False

# Command verbose flag.
verbose_cmd = False

# EC working folder name
ec_cwd = ".windbg_ec"

# EC plugins folder name
ec_plugins = "plugins"

# EC plugin's cmd folder name
ec_plugin_cmd = "cmds"
