"""
The logging of EC.

It wraps the Python logging and only exposes miniumn interfaces, such as the 'getLogger' method and log level enums. This is mostly used for debugging and troubleshotting purpose.

There are also log methods that directly and immediately write the log to Windbg console. This is mostly used for command output.

"""
import logging
from html import escape

import pykd

from ..core import color, config

CRITICAL = logging.CRITICAL
FATAL = CRITICAL
ERROR = logging.ERROR
WARNING = logging.WARNING
WARN = WARNING
INFO = logging.INFO
DEBUG = logging.DEBUG
NOTSET = logging.NOTSET


# Maintian all loggers for dealing with as a whole, e.g. update the level together
__g_loggers: dict[str, tuple[logging.Logger, int]] = {}


def getLogger(name: str = None) -> logging.Logger:
    # If cached, use it.
    cached_logger = __g_loggers.get(name or logging.root.name)
    if cached_logger:
        return cached_logger[0]

    # If not cached, populate a new one and cache it.
    # If we support specifying the level, this level need to be set according to that value.
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    handler = WindbgConsoleHandler()
    logger.addHandler(handler)

    formatter = logging.Formatter("%(levelname)s - %(name)s - %(funcName)s - %(message)s")
    handler.setFormatter(formatter)

    __g_loggers.update({logger.name: (logger, logger.level)})

    return logger


def setLevelForAllLoggers(level):
    for _, logger_info in __g_loggers.items():
        logger = logger_info[0]
        logger.setLevel(level)


def resetLevelForAllLoggers():
    for _, logger_info in __g_loggers.items():
        logger = logger_info[0]
        level = logger_info[1]
        logger.setLevel(level)


class WindbgConsoleHandler(logging.Handler):
    """
    A handler class which writes formatted logging records to Windbg console.
    """

    def __init__(self):
        # fails for super(). Python doesn't call parent constructor automatically
        logging.Handler.__init__(self)

    def emit(self, record):
        log = self.formatter.format(record)

        if not is_enabled_ec_verbose():
            return

        # match statement requires Python >3.10
        if record.levelno in (logging.CRITICAL, logging.FATAL):
            error_ec(log)
        elif record.levelno == logging.ERROR:
            error_ec(log)
        elif record.levelno in (logging.WARNING, logging.WARN):
            warn_ec(log)
        elif record.levelno == logging.DEBUG:
            debug_ec(log, force=True)
        elif record.levelno in (logging.INFO, logging.NOTSET):
            info_ec(log)


# The root logger that can be shared within the EC
rootLogger = getLogger()

# Gloable loggers
__g_loggers.update({rootLogger.name: (rootLogger, rootLogger.level)})


##### Write message directly without using Python logging #######
def info_ec(msg, newline=True):
    """
    The info_ec method prints the passed in object as string. So, you can add the color by yourself. e.g.
    logging.info_ec(color.red("dummy")) // Display red string.
    """
    getattr(pykd, "dprintln" if newline else "dprint")(str(msg), dml=True)


def debug_ec(msg, newline=True, force=False):
    if not config.verbose_cmd and not force:
        return

    getattr(pykd, "dprintln" if newline else "dprint")(color.purple(msg), dml=True)


def warn_ec(msg, newline=True):
    getattr(pykd, "dprintln" if newline else "dprint")(color.red(msg), dml=True)


def error_ec(msg, newline=True):
    getattr(pykd, "dprintln" if newline else "dprint")(color.dark_red(msg), dml=True)


#####
def enable_cmd_verbose():
    config.verbose_cmd = True


def disable_cmd_verbose():
    config.verbose_cmd = False


def enable_ec_verbose():
    config.verbose = True


def disable_ec_verbose():
    config.verbose = False


def is_enabled_ec_verbose():
    return config.verbose


def cmd_link(cmd, literal):
    return f'<link cmd="{escape(cmd)}">{literal}</link>'
