"""
Extension Commands (aka EC) for Windbg.

It provides a bunch of convenient commands written in Python for debugging and troubleshooting.
It also allows you to register command(s) for extending the capability of it.
"""
import argparse
import os
import sys

from .core import log


def __reload_modules():
    """Reload all EC modules including plugin modules"""
    modulesToDelete = []
    for m in sys.modules:
        moduleName = str(m)
        # Following module will not be removed
        if moduleName in ["ec.core.log"]:
            continue
        # Remove EC modules and EC plugin modules
        if any(moduleName.startswith(k) for k in ["ec.", "ecp."]):
            modulesToDelete.append(moduleName)

    currentModule = __name__
    for mod in modulesToDelete:
        if mod != currentModule:  # Python cannot delete the current module
            log.rootLogger.debug(f"Removing Python module [{mod}] ...")
            del sys.modules[mod]


__reload_modules()

from .command_register import *
from .core import consts
from .utils import getWorkingFolder


def __verbose(func, enable):
    if enable:
        log.enable_ec_verbose()
        log.setLevelForAllLoggers(log.DEBUG)  # may support more level in the future
    try:
        func()
    finally:
        log.disable_ec_verbose()
        log.resetLevelForAllLoggers()


def main():
    # Set working folder of EC. It switches the working folder of current Windbg process as well
    os.chdir(getWorkingFolder())

    # Register EC in Windbg
    register_ec(consts.WINDBG_EXT_EC)

    # Register EC native commands
    register_ec_native_cmds()

    # Register EC plugins
    register_ec_plugins()

    prompt = f'Successfully loaded Extension Commands for Windbg! Run [{log.cmd_link(f"{consts.WINDBG_EXT_EC} help", f"{consts.WINDBG_EXT_EC} help")}] for more details.'
    log.info_ec(prompt)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--verbose", action="store_true", help="show more output")
    args = parser.parse_args()

    __verbose(main, args.verbose)
