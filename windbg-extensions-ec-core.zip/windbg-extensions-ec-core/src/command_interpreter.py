"""
It interperts the command which is passed in as arguments and invokes the targeted function.
"""
import argparse
import inspect
import traceback
from functools import partial
from typing import Callable, Tuple

import pkg_resources

from .command_common import CmdExecError, ECArgumentParser
from .command_register import all_commands
from .core import consts, log


class CommandInterpreter:
    def __init__(self, func: Callable[[Tuple[str]], None]):
        self.func = func

    def invoke(self, args: Tuple[str]) -> None:
        try:
            self.__preInvoke()

            self.func(args)
        except CmdExecError as e:
            log.error_ec(e.errmsg)
        except Exception:
            traceback.print_exc()
        finally:
            self.__postInvoke()

    def __preInvoke(self):
        if log.is_enabled_ec_verbose():
            log.setLevelForAllLoggers(log.DEBUG)

    def __postInvoke(self):
        if log.is_enabled_ec_verbose():
            log.resetLevelForAllLoggers()

        # always reset the command verbose flag.
        log.disable_cmd_verbose()


def invokeCommand(group, cmd, args):
    CommandInterpreter(all_commands[group][cmd]).invoke(args)


def main():
    parser = ECArgumentParser(
        description="Extension Commands for Windbg",
        epilog=inspect.cleandoc(
            f"""
            For exact command help, try '{consts.WINDBG_EXT_EC} COMMAND help'
            Examples:
                print help of command 'r'
                    !ec r -h

                print help of command 'sc'
                    !ec sc -h
            """
        ),
        usage=f"{consts.WINDBG_EXT_EC} [OPTIONS] COMMAND [ARGS]...",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    version = pkg_resources.get_distribution(consts.EC).version

    parser.add_argument("-v", "--verbose", action="store_true", help="show more output")
    parser.add_argument("-d", "--debug", action="store_true", help="enable the debugger")
    parser.add_argument("-V", "--version", action="version", version=f"Extension Commands for Windbg {version}")

    subparsers = parser.add_subparsers(
        title="COMMANDS",
        description=f'Try {log.cmd_link(f"{consts.WINDBG_EXT_EC} help", f"{consts.WINDBG_EXT_EC} help")} to see all available commands',
        metavar="",
    )

    # Register all commands and their real function
    for group in all_commands:
        for cmd in all_commands[group]:
            subcmd = subparsers.add_parser(cmd, add_help=False)
            subcmd.set_defaults(func=partial(invokeCommand, group, cmd))

    args, cmd_args = parser.parse_known_args()

    # Enable verbose
    log.enable_ec_verbose() if args.verbose else log.disable_ec_verbose()

    if hasattr(args, "func"):
        # enable the debugger
        if args.debug:
            import web_pdb

            web_pdb.set_trace()

        # run command
        args.func(cmd_args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
