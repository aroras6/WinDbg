from ..command_common import *


@arg_parser(lambda parser: parser.add_argument("-o", "-O", "--open", action="store_true", help="open current workfing folder"))
def cwd(args):
    """Show currnet working folder"""

    cwd_path = getWorkingFolder()
    log.info_ec(f"Current working folder: {cwd_path}")

    if args.open:
        log.debug_ec(f"Opening folder: {cwd_path}")
        os.startfile(cwd_path)


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("-s", "--suffix", help="the suffix of the file, otherwise no suffix"),
        parser.add_argument("-p", "--prefix", help="the prefix of the file, otherwise 'ec_tmp_'"),
        parser.add_argument("-c", "--create", action="store_true", help="indicates if the physical temp file should be created")
    )
    # fmt: on
)
def tempfile(args):
    """Construct a temp file path under current working folder"""

    cwd_path = getWorkingFolder()

    filename = getRandomFilename(args.prefix, args.suffix)

    filepath = f"{cwd_path}\{filename}"
    log.info_ec(f"Temp file: {filepath}")

    if args.create:
        createfile(filepath)

    return filepath


# Register command at global.
register_ec_command(__file__, cwd)
register_ec_command(__file__, tempfile)
