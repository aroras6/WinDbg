from ..command_common import *
from ..command_register import all_commands


@arg_parser()
def help_group(args):
    """List all available commands in the group"""
    if len(args) != 1:
        raise CmdExecError("Invalid group name!")
    log.info_ec(f'Try "{consts.WINDBG_EXT_EC} COMMAND -h" for further command usage!\n')
    if args[0] == "all":
        for group in all_commands:
            for name, cmd in all_commands[group].items():
                cmd_info = inspect.cleandoc(cmd.__doc__).split("\n")[0]
                log.info_ec('<link cmd="{} {}">{:28s}</link>{}'.format(consts.WINDBG_EXT_EC, name, name, cmd_info))
    else:
        if not all_commands[args[0]]:
            raise CmdExecError("Invalid group name!")
        for name, cmd in all_commands[args[0]].items():
            cmd_info = inspect.cleandoc(cmd.__doc__).split("\n")[0]
            log.info_ec('<link cmd="{} {}">{:28s}</link>{}'.format(consts.WINDBG_EXT_EC, name, name, cmd_info))


@arg_parser()
def help(args):
    """List all available commands by group"""
    if len(args) != 0:
        raise CmdExecError("Invalid argument!")
    log.info_ec(f"All available commands of the {consts.WINDBG_EXT_EC} extension. ", False)
    log.info_ec(f'Try [<link cmd="{consts.WINDBG_EXT_EC} -h">{consts.WINDBG_EXT_EC} -h</link>] for the details usage.')
    log.info_ec("\n", False)

    __print_all_groups()


def __print_all_groups():
    log.info_ec(f'<link cmd="{consts.WINDBG_EXT_EC} help_group all">All</link> ', False)
    sorted_commands = dict(sorted(all_commands.items()))
    for name in sorted_commands.keys():
        if name == "help":
            continue

        log.info_ec(
            f'<link cmd="{consts.WINDBG_EXT_EC} help_group {name}">{name.capitalize() if len(name) > 3 else name.upper()}</link>[{len(sorted_commands[name])}] ',
            True if name.casefold() == list(sorted_commands)[-1].casefold() else False,
        )


# Register command at global.
register_ec_command(__file__, help)
register_ec_command(__file__, help_group)
