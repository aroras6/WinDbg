"""
It automatically creates Windbg aliases for the extensions.

The alias triggers the real command by passing it to command interpreter.
"""
import importlib.util
import os
import sys
from argparse import Namespace
from typing import Callable, Union

from .core import consts, dbgeng, log
from .utils import getAllCmdFiles, getPluginsFolder

# This dictionary should be declared before all commands import, since the commands also need to refer to it.
all_commands: dict[str, dict[str, Callable[[Union[list[str], Namespace]], None]]] = {}


def register_ec_command(group: Union[str, bytes, os.PathLike], cmd: Callable[[Union[list[str], Namespace]], None]) -> None:
    groupName = os.path.splitext(os.path.basename(str(group)))[0].replace(consts.EC_CMD_PREFIX, "")
    cmdGroup = all_commands.setdefault(groupName, {})
    cmdGroup[cmd.__name__] = cmd


def register_ec(cmd):
    """Register Windbg commands as alias"""
    dbgeng.set_alias(cmd, f"!py -g -m ec.command_interpreter")


def register_ec_native_cmds():
    """Import all native commands. cmd_help is special and should not be the last one"""
    from .cmds import cmd_help, cmd_utility


def register_ec_plugins():
    ec_plugins_path = getPluginsFolder()

    # Append all plugin paths to sys, so that plugin modules can be found
    plugins = [f.path for f in os.scandir(ec_plugins_path) if f.is_dir()]
    log.rootLogger.debug(plugins)

    for plugin in plugins:
        log.rootLogger.info(f"Appending [{plugin}] to sys path...")
        sys.path.append(f"{plugin}")

        # Enroll all commands
        for cmd_path in getAllCmdFiles(plugin):
            cmd_name = cmd_path.removesuffix(".py").replace(plugin, "").replace("\\", ".").lstrip(".")
            if cmd_name in sys.modules:
                # Rerun ec will remove the module, so this case only happens when there is the duplication.
                log.rootLogger.warning(f"Command [{cmd_name}] already exists! Skip adding this module.")
                continue

            log.rootLogger.info(f"Registering {consts.EC} cmmand [{cmd_name}]")

            spec = importlib.util.spec_from_file_location(cmd_name, cmd_path)
            cmd = importlib.util.module_from_spec(spec)

            try:
                spec.loader.exec_module(cmd)
                sys.modules[cmd_name] = cmd
            except Exception as e:
                log.rootLogger.error(f"Failed to initiate the command [{cmd_name}].", exc_info=True)
