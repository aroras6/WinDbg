import argparse
import inspect
from functools import wraps
from typing import Optional

# The below modules are available in each comand that imports command_common
from .command_register import register_ec_command
from .core import consts, dbgeng, log
from .core.exception import CmdExecError
from .utils import *


class ECHelpFormatter(argparse.RawDescriptionHelpFormatter):
    """
    The class that custmize the argparse help according to EC needs.
    """

    def _expand_help(self, action):
        params = vars(action)
        if params.get("choices") is not None:
            if type(params["choices"]) is dict:
                setattr(action, "ec_choices", params["choices"])

        return inspect.cleandoc(super()._expand_help(action))


class ECArgumentParser(argparse.ArgumentParser):
    """
    The class that redirects the message to Windbg console which allows DML.

    It also redefines the prog and description with function name and doc respectively.
    """

    def injectFuncDoc(self, func):
        self.prog = func.__name__
        self.description = inspect.cleandoc(func.__doc__)
        self.formatter_class = ECHelpFormatter

    def _print_message(self, message, file):
        log.info_ec(message)


def arg_parser(parser_func: Optional[Callable[[argparse.ArgumentParser], Any]] = None) -> Callable:
    def target_func_decorator(func):
        @wraps(func)
        def wrap(*args, **kwargs):
            parser = ECArgumentParser()
            parser.injectFuncDoc(func)
            parser.add_argument("-v", "--verbose", action="store_true", help="show more output")
            if parser_func:
                parser_func(parser)
            parsed_args, unknown_args = parser.parse_known_args(*args)
            log.rootLogger.debug(f"Parsed command [{func.__name__}] arguments: [{vars(parsed_args)}] and [{unknown_args}]")

            if parsed_args.verbose:
                log.enable_cmd_verbose()

            if len(vars(parsed_args)) < 2:
                # for arguments not defined in argparser. support the case that needs to forward all raw argumetns,
                # for example, declare @arg_parser(None) decorator for the command.
                # note: verbose argument can be forwarded when the argument appears twice.
                if args.count("-v") > 1 or args.count("--verbose") > 1:
                    unknown_args.append("-v")

                log.rootLogger.debug("Forwarding raw arguments to command...")
                return func(unknown_args)  # list
            else:
                # if parsed_args exist, ignore the unknown_args.
                log.rootLogger.debug("Forwarding parsed arguments to command...")
                return func(parsed_args)  # Namespace iterator

        return wrap

    return target_func_decorator
