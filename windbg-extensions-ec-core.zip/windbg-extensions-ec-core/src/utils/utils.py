"""
The common utils class.
"""
import os
from urllib.parse import quote

from .local_shell import IShellListener, LocalShell
from .utils_fs import getWorkingFolder


def is_int(val: str) -> bool:
    """Check if val is a int string"""
    try:
        if val.startswith(("0b", "0y")):
            # remove the start with chcarcters
            int(val[2:], 2)
        elif val.startswith("0x"):
            int(val[2:], 16)
        elif val.startswith("0o"):
            int(val[2:], 8)
        elif val.startswith("0n"):
            int(val[2:], 10)
        else:
            return is_hex_quo(val) or is_hex(val)
        return True
    except ValueError:
        return False


def is_hex(val: str) -> bool:
    """Check if val is a hex string"""
    try:
        int(val, 16)
        return True
    except ValueError:
        return False


def is_hex_quo(val: str) -> bool:
    """
    Check if val is a address with quotation, i.e. 0000014e'73627230
    """
    if len(val.split("`")) == 2:
        addr, offset = val.split("`")
        if is_hex(addr) and is_hex(offset):
            return True

    return False


def is_number(n):
    is_number = True
    try:
        num = float(n)
        # check for "nan" floats
        is_number = num == num  # or use `math.isnan(num)`
    except ValueError:
        is_number = False
    return is_number


def check_in_range(val: int, low: int, up: int) -> bool:
    """Check if low <= val <= up"""
    if low <= val and val <= up:
        return True
    else:
        return False


def show_html(url: str) -> None:
    spawnShell(f'start "" chrome.exe --user-data-dir="{getWorkingFolder()}/chrome-user-data-dir" --disable-web-security "{url}"')


def to_html_param(params: dict) -> str:
    return "".join([f"{k}={quote(v, safe='') if type(v) is str else v}&" for k, v in params.items()])[:-1]


def getPython() -> str:
    return f"{os.path.dirname(os.__file__)}/../python"


def runShell(cmd_line: str, cwd: str = None, listener: IShellListener = None) -> None:
    """
    It executes the shell and waits for the result.
    """
    LocalShell(cmd_line, cwd).run(listener)


def spawnShell(cmd_line: str, cwd: str = None) -> None:
    """
    It executes the shell and detaches from it.
    """
    LocalShell(cmd_line, cwd).spawn()


def interactShell(cmd_line: str, cwd: str = None, listener: IShellListener = None) -> None:
    """
    It executes the shell and enables the interation.
    """
    LocalShell(cmd_line, cwd).interact(listener)


def runPy(cmd_line: str, cwd: str = None, listener: IShellListener = None) -> None:
    runShell(f"{getPython()} {cmd_line}", cwd, listener)


def runPyDetach(cmd_line: str, cwd: str = None) -> None:
    spawnShell(f"{getPython()} {cmd_line}", cwd)


def runPyInteract(cmd_line: str, cwd: str = None, listener: IShellListener = None) -> None:
    interactShell(f"{getPython()} {cmd_line}", cwd, listener)


def runPipenv(cmd_line: str, env_folder: str = None, listener: IShellListener = None) -> None:
    runPy(f"-m pipenv run {cmd_line}", env_folder, listener)


def runPipenvDetach(cmd_line: str, env_folder: str = None) -> None:
    runPyDetach(f"-m pipenv run {cmd_line}", env_folder)


def runPipenvInteract(cmd_line: str, env_folder: str = None, listener: IShellListener = None) -> None:
    runPyInteract(f"-m pipenv run {cmd_line}", env_folder, listener)
