"""
It is the utils of file system.
"""
import json
import os
import random
import shutil
import string
import subprocess
import traceback
from pathlib import Path
from typing import Optional

from ..core import config, consts, log

__logger = log.getLogger(__name__)


def copyfile(*args, **kwargs):
    shutil.copyfile(*args, **kwargs)


def copyFolder(*args, **kwargs):
    shutil.copytree(*args, **kwargs)


def createfile(file):
    with open(file, "w") as fp:
        pass


def mkdir(cwd):
    Path(cwd).mkdir(parents=True, exist_ok=True)


def pathExists(path):
    __logger.debug(f"Checking if [{path}] exists...")
    return Path(path).exists()


def isDir(path):
    return Path(path).is_dir()


def parentFolder(file):
    return Path(file).parent


def fileSuffix(file):
    return Path(file).suffix


def getFile(directory, file):
    __logger.debug(f"Searching [{file}] under folder [{directory}]...")
    if not isDir(directory):
        __logger.debug(f"[{directory}] is not a directory.")
        return None

    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename == file:
                return os.path.join(root, filename)

    return None


def getAllCmdFiles(directory):
    __logger.debug(f"Searching all EC commands under folder [{directory}]...")
    if not isDir(directory):
        __logger.debug(f"[{directory}] is not a directory.")
        return None

    rtn_files: list[str] = []
    for root, dirs, _ in os.walk(directory):
        for dir in dirs:
            if dir == config.ec_plugin_cmd:
                for _, _, files in os.walk(os.path.join(root, dir)):
                    for file in files:
                        if file.startswith(consts.EC_CMD_PREFIX) and fileSuffix(file).lower() == ".py":
                            rtn_files.append(os.path.join(root, dir, file))

    return rtn_files


def getRandomFilename(prefix="", suffix=""):
    __logger.debug("Populating random file name...")
    prefix = "ec_tmp_" if not prefix else prefix
    __logger.debug(f"Prefix: [{prefix}]")

    suffix = f".{suffix}" if suffix else suffix
    __logger.debug(f"Suffix: [{suffix}]")

    filename = f"{prefix}{''.join(random.choices(string.ascii_letters, k=16))}{suffix}"
    __logger.debug(f"File name: [{filename}]")
    return filename


def getUserHome():
    home = str(Path.home())
    __logger.debug(f"User home directory [{home}]")
    return home


def getWorkingFolder():
    cwd = f"{getUserHome()}\\{config.ec_cwd}"
    mkdir(cwd)
    __logger.debug(f"EC working directory [{cwd}]")
    return cwd


def getPluginsFolder():
    cwd = f"{getWorkingFolder()}\\{config.ec_plugins}"
    mkdir(cwd)
    __logger.debug(f"EC plugins directory [{cwd}]")
    return cwd


def dump_object(obj: list) -> Optional[str]:
    path = f"{getWorkingFolder()}/{getRandomFilename(suffix='json')}"
    try:
        with open(path, "w+") as f:
            json.dump(obj, f)
            __logger.debug(f"Successfully dump the object to [{path}].")
            return path
    except:
        __logger.error(f"Failed to dump the object to [{path}].", exc_info=True)
        return None


def load_object(filepath: str) -> Optional[str]:
    try:
        with open(filepath, "r") as f:
            obj = json.load(f)
            __logger.debug(f"Successfully dump the object to [{filepath}].")
            return obj
    except:
        __logger.error(f"Failed to dump the object to [{filepath}].", exc_info=True)
        return None


def unregister_plugin(plugin: str) -> None:
    link = f"{getPluginsFolder()}/{plugin}"

    if pathExists(link):
        log.info_ec(f"Unregistering plugin [{plugin}]...")
        os.unlink(link)
        if not pathExists(link):
            log.info_ec(f"Successfully unregistered the plugin!")
        else:
            log.error_ec(f"Failed to unregister the plugin!")


def register_plugin(plugin: str, target: str) -> None:
    """Register plugin

    Args:
        plugin: the plugin name
        target: the plugin project root path that contains 'cmds' folder
    """
    try:
        unregister_plugin(plugin)

        log.info_ec(f"Registering plugin [{plugin}]...")

        link = f"{getPluginsFolder()}/{plugin}"
        subprocess.check_call(f'mklink /J "{link}" "{target}"', shell=True)
        log.info_ec(f"Successfully registered the plugin!")
    except:
        traceback.print_exc()
