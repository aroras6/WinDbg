"""
The class that wraps the shell execution.
"""
import os
import subprocess
import sys
import threading
from typing import IO, Any, Callable, Optional

from ..core import color, log


class IShellListener:
    def __init__(self, quiet: bool = False):
        self.quiet = quiet  # if this flag is set, it aims hide the shell outputs

    def listen(self, input: str, out: IO = None) -> None:
        """Listen the shell output and be able to write to shell stdin"""
        pass


class LocalShellListener(IShellListener):
    def __init__(self, res_count: int = 1, quiet: bool = False):
        super().__init__(quiet)
        self.history: list[str] = []
        self.res_count = res_count

    def listen(self, input: str, out: IO = None) -> None:
        super().listen(input, out)
        self.history.append(input) if self.res_count > 0 else None

    def getResult(self, parser: Callable[[str], tuple[bool, Any]]) -> tuple[bool, Optional[list]]:
        """return result when only one is needed, otherwise a list of results"""
        if self.res_count == 0:
            return False, None

        total = len(self.history)
        if total == 0:
            return False, None

        results: list = []

        for line in self.history:
            found, result = parser(line)
            if found:
                if self.res_count == 1:
                    return True, result
                else:
                    results.append(result)

            total -= 1
            if total < 1:
                break

            # Found all necessary results
            if self.res_count == len(results):
                break

        return (True, results) if len(results) > 0 else (False, None)

    def reset(self):
        self.history.clear()


class LocalShell(object):
    def __init__(self, cmd_line, cwd=None):
        self._logger = log.getLogger(self.__class__.__name__)
        self.cmd_line = cmd_line
        self.cwd = cwd
        self._logger.debug(f"Command line: [{cmd_line}]")
        self._logger.debug(f"CWD: [{cwd}]")

    def run(self, listener: IShellListener = None) -> None:
        """
        Run the shell and waits for the shell to be finished.
        """
        env = os.environ.copy()
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        process = subprocess.Popen(
            self.cmd_line,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=si,
            env=env,
            cwd=self.cwd,
            shell=True,
            encoding="utf-8",
            errors="replace",
        )

        while self.__is_alive(process):
            data = process.stdout.readline()  # type: ignore
            if data and data.strip():
                quiet_mode = listener and listener.quiet
                if not quiet_mode:
                    log.info_ec(data, False if data.endswith(("\n", "\r", "\r\n")) else True)
                if listener:
                    listener.listen(data.strip())

    def spawn(self) -> None:
        """
        Spawn the process and detach from it.
        """
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        subprocess.Popen(self.cmd_line, startupinfo=si, cwd=self.cwd, shell=True)

    def interact(self, listener: IShellListener = None) -> None:
        """
        Run the shell and allows the interaction.
        """
        self._logger.debug("Starting local terminal...")
        log.info_ec(color.purple("Use 'exit' to terminate the shell!!!"))

        env = os.environ.copy()
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        process = subprocess.Popen(
            self.cmd_line,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=si,
            env=env,
            cwd=self.cwd,
            shell=True,
            encoding="utf-8",
            errors="replace",
        )

        def pull(p: subprocess.Popen) -> None:
            self._logger.debug("Starting pull thread...")
            assert p.stdout is not None
            while self.__is_alive(p):
                try:
                    data: str = p.stdout.readline()
                    if data and data.strip():
                        quiet_mode = listener and listener.quiet
                        if not quiet_mode:
                            log.info_ec(data, False if data.endswith(("\n", "\r", "\r\n")) else True)
                        if listener:
                            listener.listen(data.strip(), p.stdin)
                    else:
                        if not data:
                            # the shell process is killed.
                            self._logger.warning('shell seems to be terminated. Run "exit" to finish the push thread!')
                            break
                except ValueError as e:
                    # ignore the I/O on closed file error, since push thread may be closed.
                    if not p.stdout.closed:
                        self._logger.error(f"Failed to run pull thread.", exc_info=True)
                    else:
                        self._logger.debug(f"Failed to run pull thread. The stdout is closed.")
                    break
                except:
                    self._logger.error(f"Fatal error happened when running pull thread!", exc_info=True)
                    break

            self._logger.debug("Successfully terminated pull thread.")

        puller = threading.Thread(target=pull, args=(process,))
        puller.start()

        def push(p: subprocess.Popen) -> None:
            self._logger.debug("Starting push thread...")
            assert p.stdin is not None
            while self.__is_alive(p):
                try:
                    input = sys.stdin.readline()
                    if input and input.strip() and self.__is_alive(p):
                        p.stdin.write(input + "\n")
                        p.stdin.flush()

                        if input.strip().casefold() == "exit":
                            try:
                                # try to froce deleting the processes on Windows
                                subprocess.run(["taskkill", "/F", "/T", "/pid", "%s" % p.pid], check=True, shell=True)
                            except:
                                pass

                            break
                except:
                    self._logger.error("Fatal error happened when running push thread!", exc_info=True)

            self._logger.debug("Successfully terminated push thread.")

        pusher = threading.Thread(target=push, args=(process,))
        pusher.start()

    def __is_alive(self, p: subprocess.Popen) -> bool:
        return p.poll() is None
