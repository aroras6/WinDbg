# Extension Commands for Windbg

The core functionalities of Extension Commands (aka EC).

## Overivew

EC (Extension Commands for Windbg) is a Python-based Windbg extension designed to expand the capabilities of Windbg through a collection of Python scripts. Leveraging pykd, EC enables the integration of third-party Python open source libraries for various purposes, including visualization and data processing. Additionally, EC is implemented as a framework that facilitates the registration of commands as plugins in a straightforward manner, enhancing the convenience and flexibility of its use.

## Quick start

1. Install Python `3.9.13`. **Note:** this is the latest 3.x version that has pykd spport.
1. Install Python `2.7.18`. **Note:** this is the latest 2.x version that has pykd support
1. Load Windbg extension named `pykd` in Windbg, i.e. `.load path\to\pykd`. **Note:** it is available in this project named `pykd.dll`.
1. Make sure `!py -h` is valid in Windbg. You will see the !py help text.
1. Make sure Python `3.9` is the selected interpreter.

    ```console
    0:001> !info

    pykd bootstrapper version: 2.0.0.25

    Installed python:

    Version:        Status:     Image:
    ------------------------------------------------------------------------------
    2.7 x86-64    Loaded      C:\Windows\SYSTEM32\python27.dll
    * 3.9 x86-64    Loaded      C:\Users\wuol\AppData\Local\Programs\Python\Python39\python39.dll
    3.11 x86-64   Unloaded    C:\Users\wuol\AppData\Local\Programs\Python\Python311\python311.dll
    ```
1. Install pykd in Python `2.7.18` and `3.9.13` respectively. e.g. `py -3.9 -m pip install pykd` and `py -2.7 -m pip install pykd`. **Note:** If you get `No module named pip` error, install it manually by downloading the `get-pip.py` first, i.e. `curl https://bootstrap.pypa.io/pip/2.7/get-pip.py --output get-pip.py`, then run `py -2.7 get-pip.py`. **Note:** Python Launcher (py) is available once you have Python install. **Note:** This step is not necessary anymore, when you install the EC, pykd module is installed automatically as a dependency.
1. Install EC as pip module. Refer to [Installation](#installation) for more detials.
1. Load EC by running `!py -g -m ec` and you will see the welcome as below.
    ```console
    Successfully loaded Extension Commands for Windbg! Run [!ec help] for more details.
    ```

## Usage

After launching EC in Windbg, its current working folder is switched to `.windbg_ec` under user home by default.

For EC usage, try `!ec -h`. For EC available commands, try `!ec help`.

## Installation

Go to the root folder of this project, and run following:

```cmd
py -m pip install .
```

It installs EC as pip moudel, hence it can be imported by other python project. Once there is any update, rerun the install.

If you also want to develop the EC, please install the dev dependencies as below:
```cmd
py -m pip install .[dev]
```
It also installs the dependencies used for developement.

## Development

### Plugin
EC allows for expansion through the use of plugins. To create an EC plugin, the plugin should have a folder called `ecp`, which indicates that it is an EC plugin. Within the `ecp` folder, there should be a subfolder that indicates the name of the specific plugin. Within this subfolder, there should be a `cmds` subfolder that contains EC commands that start with `cmd_`. For example:
```dos
src
└───ecp
    └───basic
        ├───cmds
        │       cmd_basic.py
        │       cmd_utility.py
        │
        └───common
                context.py
                suo.py
```
You can create any other folders that the plugin needs, and the `cmds` folder should contain the specific commands that the plugin provides. These commands can then be executed within the EC system.

Finally, call `register_plugin(plugin: str, target: str)` method to register the plugin, and `unregister_plugin(plugin: str)` methdo to unregister the plugin.

**Note:** the plugin should be registered at the parent folder of `ecp` folder, i.e. `src` folder (any name works) in this sample, hence the module search path is started from there, e.g. `ecp.basic.common.suo`.

The available plugins are:
- windbg-extensions-ec-basic
- windbg-extensions-ec-advance
- windbg-extensions-ec-geodesy

### How to write a command
EC allows the registration of custom commands, which can be easily invoked and organized within the extension. To create a custom command, follow these steps:

1. Define a method that accepts a list of arguments.
    ```python
    def my_method(args):
    ```
1. Add the doc to describe the funcationality. This is mandatory.
1. Add the `arg_parser` function decorator, which accepts a lambda function that injects an argparse parser instance.
    ```python
    @arg_parser()
    ```
1. Register the command by defined the `register_ec_command` method with file name as the group name in command module. It will be automatically invoked.
    ```python
    register_ec_command(__file__, my_method)
    ```

By following these steps, you can quickly create and register custom commands within EC, providing greater flexibility and customization options to your debugging workflow.

### Reload module

Run `!py -g -m ec` reloads all EC modules including those plugin ones.

### Logging

There are 2 types of logging, one is leveraging Python logging which is used for EC framework itself and utils, and the other writes the message directly to Windbg console. The latter one is for command output.

The former one, use `!ec -v` to enable it:

```python
import log

logger = log.getLogger(self.__class__.__name__)
logger.info(...)
logger.debug(...)
```

The latter one, use `!ec COMMAND -v` to enable it:

```python
import log

log.info_ec(...)
log.debug_ec(...)
```

### Formatter, Sort and Linting

The `pyproject.toml` file includes the configurations for `Black` and `isort`. These settings are directly used by VSCode.

Before submitting your code, it is important to ensure that it is properly linted and formatted. To do this, you can install `pre-commit` by running `py -m pip install pre-commit` in your terminal. Then, install the Git hook by running `pre-commit install`.

Every time you commit your code, `pre-commit` will be run automatically. If you wish to run it manually, you can do so by running `pre-commit run -a` in your terminal.

### Debugging

The pdb can be used for pykd in Windbg. More convenient way is to have a debugger gui. Unfortunately, Mircosoft debugpy doesn't seem to work well in Windbg, hence we choose the [web-pdb](https://github.com/romanvm/python-web-pdb).

Install the `web-pdb` in `python39` that runs pykd.

```cmd
py -m pip install web-pdb
```

Then, when executing specific command, add `-d` argument, e.g.,

```cmd
!ec -d cwd
```

By using `-v` argument, you will see a reminder for opening browser with specific url.

```console
CRITICAL - root - __init__ - Web-PDB: starting web-server on SHAPC2L06XG:5555...
```

Within the browser, all `pdb` commands are available. For example, you can add breakpoint like `b ecp\\basic\\cmds\\cmd_utility:15`. you can remove all breakpoints by `cl` (**Note:** the hint is printed in Windbg input, so, you have to enter Y/N there for pdb to continue executing).

Remember to finish the execution and `web-pdb` server stops. Close the browser without finish the execution causes Windbg input waiting forever. In case that, open the browser again, and finish the execution.

```console
CRITICAL - root - close - Web-PDB: stopping web-server...
CRITICAL - root - close - Web-PDB: web-server stopped.
```

EC command `-d` argument automatically sets breakpoint for you. Alternatively, you can add `import web_pdb; web_pdb.set_trace()` to any place you want to start debugging.

## License

[MIT](../../LICENSE)

## References

-   [pykd API Reference](https://githomelab.ru/pykd/pykd/-/wikis/API%20Reference)
-   [argparse API Reference](https://docs.python.org/3/library/argparse.html)

## Dependencies

| Name                                                    | License                            | Vendored Version |
| ------------------------------------------------------- | ---------------------------------- | ---------------- |
| [pykd](https://githomelab.ru/pykd/pykd)                 | MIT                                | 0.3.4.15         |
| [argparse](https://github.com/ThomasWaldmann/argparse/) | Python Software Foundation License | 1.4.0            |
