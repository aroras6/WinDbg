import os

from ec.core import log
from ec.utils import runPipenv, runPipenvDetach

from ecp.geodesy.common.consts import *

__logger = log.getLogger(__name__)


def getWebResourceFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "web")
    path = os.path.abspath(path)
    __logger.debug(f"EC geodesy web resource folder: {path}")

    return path


def getVirtualEnvFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "venvs")
    path = os.path.abspath(path)
    __logger.debug(f"EC geodesy virtual environment folder: {path}")

    return path


def getScriptFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "scripts")
    path = os.path.abspath(path)
    __logger.debug(f"EC geodesy scripts folder: {path}")

    return path


def show_geodesy_map(payload: str):
    __execute("geodesy_map.py", payload)


def execute_geodesy_util_method(payload: str, listener=None):
    __execute("geodesy_utils.py", payload, listener=listener)


def __execute(handler: str, payload: str, env: str = EC_PYENV_GEODESY, listener=None):
    """Execute script by specified handler with the payload.

    Args:
        handler: The py file that deals with the specific payload.
        payload: The file that stores graphic payload.
    """
    cmd_line = f"python {getScriptFolder()}/{handler} --payload {payload}"
    env_path = f"{getVirtualEnvFolder()}/{env}"

    if listener:
        runPipenv(cmd_line, env_path, listener)
    else:
        runPipenvDetach(cmd_line, env_path)
