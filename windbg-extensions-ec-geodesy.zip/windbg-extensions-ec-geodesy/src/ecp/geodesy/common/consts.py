"""
It defines the constants.
"""

# Python environments
EC_PYENV_GEODESY = "geodesy"

# OS environments
ENV_CSMAP_CWD = "CSMAP_CWD"