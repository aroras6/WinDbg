function getParameters() {
    const params = new Map();

    if (!window.location.search) return params;    
    
    const params_str = window.location.search.slice(1).split('&');    
    for (let p = 0; p < params_str.length; p++) {
        let nv = params_str[p].split('=');
        let name = nv[0],
            value = nv[1];
        params.set(name, value);
    }

    return params;
}
