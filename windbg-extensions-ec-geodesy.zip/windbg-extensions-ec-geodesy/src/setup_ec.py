import argparse
import os
import subprocess

from ec.utils import register_plugin, unregister_plugin

from ecp.geodesy.common.utils import getVirtualEnvFolder


def __get_root_folder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.abspath(path)
    return path


plugin = "geodesy"


def __venv_init():
    target = f"{getVirtualEnvFolder()}/{plugin}"

    subprocess.check_call("py -3.9 -m pipenv install", cwd=f"{target}", shell=True)


def __venv_rm():
    target = f"{getVirtualEnvFolder()}/{plugin}"

    subprocess.check_call("py -3.9 -m pipenv --rm", cwd=f"{target}", shell=True)


def __register():
    target = f"{__get_root_folder()}"

    register_plugin(plugin, target)


def __unregister():
    unregister_plugin(plugin)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-u", action="store_true", help="unregister plugin")
    args = parser.parse_args()

    __venv_init() if not args.u else __venv_rm()
    __register() if not args.u else __unregister()


if __name__ == "__main__":
    main()
