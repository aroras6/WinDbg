# windbg-extensions-ec-geodesy
The geodesy commands for EC.

## Installation
```
py src\setup_ec.py
```