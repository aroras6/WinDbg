# windbg-extensions-ec-basic
The basic commands for EC.

## Installation
```
py -m pip install -r requirements.txt
py src\setup_ec.py
```