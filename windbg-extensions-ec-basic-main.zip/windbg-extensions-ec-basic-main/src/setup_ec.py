import argparse
import os
import sys

from ec.utils import register_plugin, unregister_plugin

plugin = "basic"


def __get_root_folder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.abspath(path)
    return path


def __register():
    target = f"{__get_root_folder()}"

    register_plugin(plugin, target)


def __unregister():
    unregister_plugin(plugin)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("-u", action="store_true", help="unregister")

    args = parser.parse_args(sys.argv[1:])

    __register() if not args.u else __unregister()


if __name__ == "__main__":
    main()
