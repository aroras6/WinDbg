import os

from ec.core import log
from ec.utils import *

__logger = log.getLogger(__name__)


def get_3rdparty_folder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "..", "..", "tools")
    path = os.path.abspath(path)
    __logger.debug(f"Retrieved 3rdParty tools folder [{path}]")
    return path


def runES(args, listener: LocalShellListener = None):
    cmd_line = f"{get_3rdparty_folder()}/es.exe {' '.join(args)}"
    __logger.debug(cmd_line)

    runShell(cmd_line, listener=listener)

    return listener if listener else None
