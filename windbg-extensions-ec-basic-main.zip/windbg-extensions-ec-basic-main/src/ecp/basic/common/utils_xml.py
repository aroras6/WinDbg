import xml.etree.ElementTree as ET

from ec.core import log

__logger = log.getLogger(__name__)


def read_debugtarget_history(file):  
    if not file: return None  
    
    # Load the XML file
    try:
        tree = ET.parse(file)
    except:
        __logger.error(f"Failed to parse the file [{file}]")
        return None

    # Get the root element
    root = tree.getroot()

    # Find the 'History' node
    history_node = root.find("./TargetOptions/Option[@name='RestoreCommandHistory']/Property[@name='History']")
    if not history_node: return None

    # Get all the property values of the 'History' node
    property_values = [property_node.attrib["value"] for property_node in history_node.findall("./Property")]

    # Print the property values
    __logger.debug(property_values)

    return property_values
