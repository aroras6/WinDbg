import struct

import pythoncom
from ec.core import log
from win32com.storagecon import *

__logger = log.getLogger(__name__)


def read_suo(suo_file_path):
    breakpoints: list[tuple[str, int]] = []

    # Open the .suo file
    storage = pythoncom.StgOpenStorage(suo_file_path, None, STGM_READ | STGM_SHARE_EXCLUSIVE)
    stream = storage.OpenStream("DebuggerBreakpoints", None, STGM_READ | STGM_SHARE_EXCLUSIVE)

    # Read the stream data into a buffer
    buffer: bytes = stream.Read(stream.Stat()[2])

    first_line = True
    buffer_size = len(buffer)
    for i in range(buffer_size):
        if chr(buffer[i]) == ":" and i + 3 < buffer_size and i >= 10 and chr(buffer[i + 2]) == "\\":
            if first_line:
                sln_dir_path_len = struct.unpack("<I", buffer[i - 6 : i - 2])[0]
                sln_dir = buffer[i - 2 : i - 2 + sln_dir_path_len - 2].decode("utf-16")                
                first_line = False
            else:
                if struct.unpack("<I", buffer[i - 10 : i - 6])[0] == 4:
                    line_length = struct.unpack("<I", buffer[i - 6 : i - 2])[0]
                    bp_file = buffer[i - 2 : i - 4 + line_length].decode("utf-16").replace("\\\\", "\\")
                    bp_line_num = struct.unpack("<I", buffer[i - 2 + line_length : i - 2 + line_length + 4])[0]

                breakpoints.append((bp_file, bp_line_num + 1))

        i = i + 1

    __logger.debug(f"Retrieved the breakpoints {breakpoints}")
    return sln_dir, breakpoints
