from ec.command_common import *
from ec.utils import LocalShellListener

from ecp.basic.common import suo, utils, utils_xml

import datetime


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("suo", help="the absolute path of Visual Studio .suo file"),
    )
    # fmt: on
)
def list_vs_bp(args):
    """List breakpoint(s) from Visual Studio suo"""

    sln_dir, bps = suo.read_suo(args.suo)

    bp_lines: list[str, str, str] = []
    max_module_name_len = 0
    for file, line in bps:
        module = None

        if sln_dir:  # Figure/guess out module. Normally speaking, the solution directory should exist
            last_delimiter = file.rfind("\\")
            es_cli_args = f"-path {sln_dir} /a-d *.vcxproj content:{file[last_delimiter + 1:]}"
            log.debug_ec(f"Searching module by [es {es_cli_args}]")

            found, vs_projects = utils.runES([es_cli_args], LocalShellListener(sys.maxsize, quiet=True)).getResult(
                lambda line: (line.endswith("vcxproj"), line)
            )
            if found:
                proj = ""
                max_same_chars = ""
                for p in vs_projects:
                    log.debug_ec(f"Checking [{p}] with [{file}]")
                    same_chars = ""
                    for x, y in zip(p, file):
                        if x == y:
                            same_chars += x
                        else:
                            break
                    log.debug_ec(f"The matched string [{same_chars}]")
                    if len(same_chars) > len(max_same_chars):
                        proj = p
                        max_same_chars = same_chars

                log.debug_ec(f"Found best match project [{proj}]")
                module = proj[proj.rfind("\\") + 1 : proj.rfind(".")]
                max_module_name_len = len(module) if len(module) > max_module_name_len else max_module_name_len
            else:
                log.debug_ec(f"No vs project found!")

        bp_lines.append([module, file, line])
        log.debug_ec(f"Found breakpoints [{bp_lines}]")

    for module, file, line in bp_lines:
        m_found = False

        if module:
            # Try to figure out the module name according to loaded and unloaded modules
            m_found = module.casefold() in (m_name.casefold() for m_name in dbgeng.exec_command("lm1m").split("\n"))
            if not m_found:
                for m_name in dbgeng.exec_command("lm1m").split("\n"):
                    if m_name.removesuffix(".dll").casefold() == f"{module}d".casefold():
                        module = f"{module}d"
                        m_found = True
                        break

        # Try to figure out the virtual address at the line of file
        # If the module is None, it fails immediately (since there is '!' mark) and avoids loading all modules for symbols
        addr = dbgeng.to_addr(f"`{module}!{file}:{line}`")

        col_breakpoint = log.cmd_link(f"bu `{module + '!' if module else ''}{file}:{line}`", "Breakpoint " if m_found else "Breakpoint?")
        col_module = log.cmd_link(f"lmDvm {module}", module) if module else "Unknown"
        col_module += " " * (max_module_name_len - len(module if module else "Unknown"))
        col_file = log.cmd_link(f".open -a {hex(addr)}" if addr else f'.open "{file}"', f"{file}:{line}")

        log.info_ec(f"{col_breakpoint} - {col_module} - {col_file}")


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("suo_pattern",  nargs="?", default="", help="the pattern of searching suo file"),
    )
    # fmt: on
)
def list_vs_suo(args):
    """List Visual Studio suo configuration(s) on local machine"""

    es_cli_args = f"/a-d -r ^(?=.*{args.suo_pattern})(?=.*\\\\.vs).*\\\\.suo$"

    listener = LocalShellListener(sys.maxsize, True)
    utils.runES([es_cli_args], listener)

    listener.getResult(lambda line: (True, log.info_ec(log.cmd_link(f"!ec list_vs_bp {line}", line))))


@arg_parser()
def reboot_ec(args):
    """Reboot the EC"""
    log.warn_ec(log.cmd_link("!py -g -m ec", "Click here to reboot!"))


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("num", type=int, nargs="?", default=0, help="the count of latest command(s)"),
    )
    # fmt: on
)
def history(args):
    """List commands history of the debug session

    The latest *.debugTarget is looked up.
    Note: since Windbg preview saves debugTarget when closing, this EC command is not able to read Windbg commands history on live.
    """

    def _read_history(config):
        cmds = utils_xml.read_debugtarget_history(config)
        if not cmds:
            log.warn_ec("No command found!")
            return

        for cmd in cmds[-args.num :]:
            log.info_ec(log.cmd_link(cmd, cmd))

    es_cli_args = f"/a-d /o-d -n 1 *.debugTarget"
    utils.runES([es_cli_args], LocalShellListener(quiet=True)).getResult(lambda config: (True, _read_history(config)))


@arg_parser(lambda parser: parser.add_argument("addr", help="the address of a FILETIME"))
def show_filetime(args):
    """Display a FILETIME value in a human-readable format.

    Args:
        addr: the address of a FILETIME.

    Returns:
        A string representing the FILETIME value.
    """

    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Invalid address of FILETIME. Error: [{errmsg}]")

    ft_addr = dbgeng.to_addr(args.addr)
    low = dbgeng.read_dword(ft_addr)
    high = dbgeng.read_dword(ft_addr + 4)
    filetime = (high << 32) | low

    # Convert the FILETIME to a datetime object.
    dt = datetime.datetime.fromtimestamp(filetime / 10000000 - 11644473600)

    # Convert the datetime object to a string.

    log.info_ec(dt.strftime("%Y-%m-%d %H:%M:%S"))


# Register command at global.
register_ec_command(__file__, reboot_ec)
register_ec_command(__file__, history)
register_ec_command(__file__, list_vs_bp)
register_ec_command(__file__, list_vs_suo)
register_ec_command(__file__, show_filetime)
