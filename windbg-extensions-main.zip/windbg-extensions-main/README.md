# Project Status:  🚨 Unmaintained 🚨

This project is no longer maintained. We will not be accepting pull requests, addressing issues, nor making future releases.

## Alternatives

1. EC

    - [windbg-extensions-ec-core](https://git.autodesk.com/wuol/windbg-extensions-ec-core)
    - [windbg-extensions-ec-basic](https://git.autodesk.com/wuol/windbg-extensions-ec-basic)
    - [windbg-extensions-ec-geodesy](https://git.autodesk.com/wuol/windbg-extensions-ec-geodesy)

    Note: other commands will be migrated soon.

1. cmdtree

    - [windbg-extensions-cmdtree](https://git.autodesk.com/wuol/windbg-extensions-cmdtree)

1. natvis

    - [windbg-extensions-natvis](https://git.autodesk.com/wuol/windbg-extensions-natvis)


# Windbg Extensions

## Overview
It is an extension toolkit of Windbg. 

## Extensions
### cmdtree
This moudel has been moved to [windbg-extensions-cmdtree](https://git.autodesk.com/wuol/windbg-extensions-cmdtree) repo. You can still update it as submodule.

### script
#### Javascript extension
It is based on Windbg Debugger Object Model. The Javascript is interpreted by [Mircosoft Chakra](https://en.wikipedia.org/wiki/Chakra_(JScript_engine)) (JScript engine).

#### Python extension
[Python scripts](./script/py/README.md) for Windbg.

### visualizer
This moudel has been moved to [windbg-extensions-natvis](https://git.autodesk.com/wuol/windbg-extensions-natvis) repo. You can still update it as submodule.