﻿"use strict";

function ListProcessModules() {
  //An example on how to use LINQ queries in JavaScript
  //Instead of a Lambda expression supply a function which returns a boolean for Where clause or

  let mods = host.currentProcess.Modules.Where(function (k) {
    return k.Name.includes("dll");
  }).Select(function (k) {
    return { name: k.Name, adder: k.BaseAddress };
  });

  for (var lk of mods) {
    host.diagnostics.debugLog(
      lk.name + " at " + lk.adder.toString(16) + "\r\n"
    );
  }
}

function initializeScript() {
  return [new host.functionAlias(ListProcessModules, "helloworld")];
}
