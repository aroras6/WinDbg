from common import logging


class BaseProxy:
    """
    Proxy a module or an object with advices.
    """

    def __init__(self, other):
        self._logger = logging.getLogger(self.__class__.__name__)
        self.other = other

    def _before(self, func, args, kwargs):
        return True

    def _afterReturning(self, result):
        pass

    def _after(self, result):
        return result

    def _afterThrowing(self, e) -> bool:
        """Handle after throwing advice. The return value indicates if exception should be raised again. True to raise."""
        return True

    def __getattr__(self, name):
        if hasattr(self.other, name):
            attr = getattr(self.other, name)
            return lambda *args, **kwargs: self.__wrap(attr, args, kwargs)

        raise AttributeError(name)

    def __wrap(self, func, args, kwargs):
        result = None

        try:
            self._before(func, args, kwargs)

            result = func(*args, **kwargs)
        except BaseException as e:
            if self._afterThrowing(e):
                raise e
            else:
                return None

        else:
            self._afterReturning(result)
        finally:
            result = self._after(result)

        return result


class LogProxy(BaseProxy):
    """
    It prints the parameter(s), return value(s) and exception if exists for proxied object.
    """

    def __init__(self, other):
        super().__init__(other)

    def _before(self, func, args, kwargs):
        self._logger.debug(f"Function: {self.other.__name__+'.' if hasattr(self.other, '__name__') else ''}{func.__name__} (args: {args}, kwargs: {kwargs})")
        return super()._before(func, args, kwargs)

    def _after(self, result):
        self._logger.debug(f"Final return: {result}")
        return super()._after(result)

    def _afterThrowing(self, e):
        err = str(e).replace("\n", " ")
        self._logger.debug(f"Error: {err}")
        return super()._afterThrowing(e)


class ErrorWaiveProxy(BaseProxy):
    def __init__(self, other):
        super().__init__(other)

    def _afterThrowing(self, e):
        self._logger.debug(f"Ignore the error: [{e}]")
        return False


class NoneAsEmptyStrProxy(BaseProxy):
    def __init__(self, other):
        super().__init__(other)

    def _after(self, result):
        if result == None:
            self._logger.debug(f"Consider None as empty string!")
            return ""

        return result
