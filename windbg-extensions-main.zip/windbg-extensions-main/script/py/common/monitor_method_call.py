from common import context, dbgeng, logging


class monitor_method_call:
    """
    It monitors specified method call by setting breakpoints at the entry and return addresses.

    The module and method names must be provided for figuring out the symbol.
    """

    def __init__(self, module: str, method: str):
        self._logger = logging.getLogger(self.__class__.__name__)
        self.module = module
        self.method = method
        self.start_addr = module and method and dbgeng.get_address(f"{module}!{method}")
        self.ret_addr = None
        self.isValid = self.start_addr is not None
        self.bp_enter = None
        self.bp_ret = None

    def __del__(self):
        self.stop()

    def start(self, output=None):
        if self.isValid:
            self._logger.debug(f"Setting method enter breakpoint at [{hex(dbgeng.to_addr(self.start_addr))}]")
            self.bp_enter = dbgeng.set_breakpoint(dbgeng.to_addr(self.start_addr), self.enter_callback)

            self._logger.debug(f"Setting the output file for {self.__class__.__name__}...")
            self.output = output

        else:
            self._logger.debug("Failed to start the monitor due to invalid method address!")

    def stop(self):
        if self.bp_enter:
            self._logger.debug(f"Removing breakpoint [{self.bp_enter}]...")
            self.bp_enter.remove()
            self.bp_enter = None

        if self.bp_ret:
            self._logger.debug(f"Removing breakpoint [{self.bp_ret}]...")
            self.bp_ret.remove()
            self.bp_ret = None

        if self.output:
            if not self.output.closed:
                self._logger.debug(f"Closing output file...")
                self.output.close()
                self.output = None

    def enter_callback(self):
        if self.bp_ret == None:
            res = dbgeng.exec_command(f"uf {self.module}!{self.method}")
            disas = res and res.split("\n")
            for i in disas:
                if "ret" in i:
                    self.ret_addr = i.split()[0]
                    break

            if self.ret_addr:
                self._logger.debug(f"Setting {self.__class__.__name__} return breakpoint at [{hex(dbgeng.to_addr(self.ret_addr))}]")
                self.bp_ret = dbgeng.set_breakpoint(dbgeng.to_addr(self.ret_addr), self.return_callback)

        return False

    def return_callback(self):
        return False

    def isX64(self):
        return context.ARCH == "x64"

    def dump(self, text):
        if self.output:
            self.output.write(text)
            self.output.flush()


class handle_allocate_heap(monitor_method_call):
    def __init__(self):
        super().__init__("ntdll", "RtlpAllocateHeapInternal")
        self.bp_hit = 0

    def enter_callback(self):
        self.bp_hit += 1

        self.out = "RtlAllocateHeap("
        if not self.isX64():
            esp = dbgeng.get_register("esp")
            self.out += hex(dbgeng.read_ptr_value(esp + 4)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0x8)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0xC)) + ") = "
        else:
            self.out += hex(dbgeng.get_register("rcx")) + " , "
            self.out += hex(dbgeng.get_register("rdx")) + " , "
            self.out += hex(dbgeng.get_register("r8")) + ") = "

        self._logger.debug(f"RtlAllocateHeap enter: {self.out}")

        return super().enter_callback()

    def return_callback(self):
        if self.bp_hit == 1:
            self.out += hex(dbgeng.get_register("rax" if self.isX64() else "eax")) + "\n"
            self._logger.debug(f"RtlAllocateHeap ret: {self.out}")
            self.dump(self.out)

        if self.bp_hit > 0:
            self.bp_hit -= 1

        return super().return_callback()


class handle_free_heap(monitor_method_call):
    def __init__(self):
        super().__init__("ntdll", "RtlpFreeHeapInternal")  # RtlpFreeHeapInternal
        self.bp_hit = 0

    def enter_callback(self):
        self.bp_hit += 1

        self.out = "RtlFreeHeap("
        if not self.isX64():
            esp = dbgeng.get_register("esp")
            self.out += hex(dbgeng.read_ptr_value(esp + 4)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0x8)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0xC)) + ") = "
        else:
            self.out += hex(dbgeng.get_register("rcx")) + " , "
            self.out += hex(dbgeng.get_register("rdx")) + " , "
            self.out += hex(dbgeng.get_register("r8")) + ") = "

        self._logger.debug(f"RtlFreeHeap enter: {self.out}")

        return super().enter_callback()

    def return_callback(self):
        if self.bp_hit == 1:
            self.out += hex(dbgeng.get_register("rax" if self.isX64() else "eax")) + "\n"
            self._logger.debug(f"RtlFreeHeap ret: {self.out}")
            self.dump(self.out)

        if self.bp_hit > 0:
            self.bp_hit -= 1

        return super().return_callback()


class handle_realloc_heap(monitor_method_call):
    def __init__(self):
        super().__init__("ntdll", "RtlpReAllocateHeapInternal")
        self.bp_hit = 0

    def enter_callback(self):
        self.bp_hit += 1

        self.out = "RtlReAllocateHeap("
        if not self.isX64():
            esp = dbgeng.get_register("esp")
            self.out += hex(dbgeng.read_ptr_value(esp + 4)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0x8)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0xC)) + " , "
            self.out += hex(dbgeng.read_word_value(esp + 0x10)) + ") = "
        else:
            self.out += hex(dbgeng.get_register("rcx")) + " , "
            self.out += hex(dbgeng.get_register("rdx")) + " , "
            self.out += hex(dbgeng.get_register("r8")) + " , "
            self.out += hex(dbgeng.get_register("r9")) + ") = "

        self._logger.debug(f"RtlReAllocateHeap enter: {self.out}")

        return super().enter_callback()

    def return_callback(self):
        if self.bp_hit == 1:
            self.out += hex(dbgeng.get_register("rax" if self.isX64() else "eax")) + "\n"
            self._logger.debug(f"RtlReAllocateHeap ret: {self.out}")
            self.dump(self.out)

        if self.bp_hit > 0:
            self.bp_hit -= 1

        return super().return_callback()
