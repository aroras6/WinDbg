import math
import re


def dms_to_dd(dms_str):
    """Converting Degrees, Minutes, Seconds formatted coordinate strings to decimal

    Formula:
        DEC = (DEG + (MIN * 1/60) + (SEC * 1/60 * 1/60))

    Assumes S/W are negative.

        >>> dms2dec(utf8(48°53'10.18"N))
        48.8866111111

        >>> dms2dec(utf8(2°20'35.09"E))
        2.34330555556F

        >>> dms2dec(utf8(48°53'10.18"S))
        -48.8866111111F

        >>> dms2dec(utf8(2°20'35.09"W))
        -2.34330555556F

    """

    dms_str = re.sub(r"\s", "", dms_str)

    sign = -1 if re.search("[swSW]", dms_str) else 1

    numbers = [*filter(len, re.split("\D+", dms_str, maxsplit=4))]

    degree = numbers[0]
    minute = numbers[1] if len(numbers) >= 2 else "0"
    second = numbers[2] if len(numbers) >= 3 else "0"
    frac_seconds = numbers[3] if len(numbers) >= 4 else "0"

    second += "." + frac_seconds
    return sign * (int(degree) + float(minute) / 60 + float(second) / 3600)


def dd_to_dms(degs):
    d = int(degs)
    m = int((degs - d) * 60)
    s = (degs - d - m / 60) * 3600.00
    z = round(s, 2)
    if d >= 0:
        print(abs(d), "º", abs(m), "'", abs(z), '"', "N")
    else:
        print(abs(d), "º", abs(m), "'", abs(z), '"', "S")


class GeodesyCorrdinateSystemConversion:
    """
    The following methods are the implementations mentioned at https://en.wikipedia.org/wiki/Geographic_coordinate_conversion#From_geodetic_to_ECEF_coordinates
    In CsMap, the corresponding implementation can be found in CS_dtcalc.c

    """

    def __init__(self, semi_major = 6378137, semi_minor = 6356752.3142):
        self.semi_major = semi_major
        self.semi_minor = semi_minor
        self.f = (self.semi_major - self.semi_minor) / self.semi_major
        self.e_sq = self.f * (2 - self.f)

    def geodetic_to_ecef(self, lat, lon, h):
        lamb = math.radians(lat)
        phi = math.radians(lon)
        s = math.sin(lamb)
        N = self.semi_major / math.sqrt(1 - self.e_sq * s * s)

        sin_lambda = math.sin(lamb)
        cos_lambda = math.cos(lamb)
        sin_phi = math.sin(phi)
        cos_phi = math.cos(phi)

        x = (h + N) * cos_lambda * cos_phi
        y = (h + N) * cos_lambda * sin_phi
        z = (h + (1 - self.e_sq) * N) * sin_lambda

        return x, y, z

    def ecef_to_enu(self, x, y, z, lat0, lon0, h0):
        lamb = math.radians(lat0)
        phi = math.radians(lon0)
        s = math.sin(lamb)
        N = self.semi_major / math.sqrt(1 - self.e_sq * s * s)

        sin_lambda = math.sin(lamb)
        cos_lambda = math.cos(lamb)
        sin_phi = math.sin(phi)
        cos_phi = math.cos(phi)

        x0 = (h0 + N) * cos_lambda * cos_phi
        y0 = (h0 + N) * cos_lambda * sin_phi
        z0 = (h0 + (1 - self.e_sq) * N) * sin_lambda

        xd = x - x0
        yd = y - y0
        zd = z - z0

        t = -cos_phi * xd - sin_phi * yd

        xEast = -sin_phi * xd + cos_phi * yd
        yNorth = t * sin_lambda + cos_lambda * zd
        zUp = cos_lambda * cos_phi * xd + cos_lambda * sin_phi * yd + sin_lambda * zd

        return xEast, yNorth, zUp

    def enu_to_ecef(self, xEast, yNorth, zUp, lat0, lon0, h0):
        lamb = math.radians(lat0)
        phi = math.radians(lon0)
        s = math.sin(lamb)
        N = self.semi_major / math.sqrt(1 - self.e_sq * s * s)

        sin_lambda = math.sin(lamb)
        cos_lambda = math.cos(lamb)
        sin_phi = math.sin(phi)
        cos_phi = math.cos(phi)

        x0 = (h0 + N) * cos_lambda * cos_phi
        y0 = (h0 + N) * cos_lambda * sin_phi
        z0 = (h0 + (1 - self.e_sq) * N) * sin_lambda

        t = cos_lambda * zUp - sin_lambda * yNorth

        zd = sin_lambda * zUp + cos_lambda * yNorth
        xd = cos_phi * t - sin_phi * xEast
        yd = sin_phi * t + cos_phi * xEast

        x = xd + x0
        y = yd + y0
        z = zd + z0

        return x, y, z

    def ecef_to_geodetic(self, x, y, z):
        w2 = x * x + y * y
        w = math.sqrt(w2)
        z2 = z * z
        lon_rad = math.atan2(y, x)

        a1 = self.semi_major * self.e_sq
        a2 = a1 * a1
        a3 = a1 * self.e_sq / 2
        a4 = 2.5 * a2
        a5 = a1 + a3
        # a6 = (1 - self.e_sq)

        r2 = w2 + z2
        r2 = 0.0000001 if r2 == 0 else r2

        r = math.sqrt(r2)

        s2 = z2 / r2
        c2 = w2 / r2
        u = a2 / r
        v = a3 - a4 / r

        s = 0
        c = 0
        ss = 0

        # cos(45 deg)^2 == 0.5
        if c2 > 0.5:  # Equatorial
            s = (z / r) * (1 + c2 * (a1 + u + s2 * v) / r)
            lat_rad = math.asin(s)
            ss = s * s
            c = math.sqrt(1 - ss)
        else:  # Polar
            c = (w / r) * (1 - s2 * (a5 - u - c2 * v) / r)
            lat_rad = math.acos(c)
            ss = 1 - c * c
            s = math.sqrt(ss)

            if z < 0:
                lat_rad = -lat_rad
                s = -s

        d2 = 1 - self.e_sq * ss
        Rn = self.semi_major / math.sqrt(d2)
        Rm = (1 - self.e_sq) * Rn / d2
        rf = (1 - self.e_sq) * Rn
        u = w - Rn * c
        v = z - rf * s
        f = c * u + s * v
        m = c * v - s * u
        p = m / (Rm + f)

        lat_rad += p

        ht = f + m * p / 2

        return math.degrees(lat_rad), math.degrees(lon_rad), ht

    def geodetic_to_enu(self, lat, lon, h, lat_ref, lon_ref, h_ref):
        x, y, z = self.geodetic_to_ecef(lat, lon, h)

        return self.ecef_to_enu(x, y, z, lat_ref, lon_ref, h_ref)

    def enu_to_geodetic(self, xEast, yNorth, zUp, lat_ref, lon_ref, h_ref):
        x, y, z = self.enu_to_ecef(xEast, yNorth, zUp, lat_ref, lon_ref, h_ref)

        return self.ecef_to_geodetic(x, y, z)
