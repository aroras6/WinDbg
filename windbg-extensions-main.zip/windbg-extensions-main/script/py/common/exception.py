"""
The exceptions of EC.
"""

class CmdExecError(Exception):
    def __init__(self, errmsg):
        self.errmsg = errmsg
