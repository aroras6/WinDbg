import sys
from functools import wraps

from common import color, config, dbgeng, logging

ARCH = None
PTRMASK = None
PTRSIZE = None
MAX_DEREF = 20


def init_arch():
    global ARCH, PTRMASK, PTRSIZE
    cpu_mode = dbgeng.get_cpu_mode()
    if cpu_mode == dbgeng.CPUType.I386:
        ARCH = "x86"
        PTRMASK = 0xFFFFFFFF
        PTRSIZE = 4
    elif cpu_mode == dbgeng.CPUType.AMD64:
        ARCH = "x64"
        PTRMASK = 0xFFFFFFFFFFFFFFFF
        PTRSIZE = 8
    else:
        logging.error_ec(f"CPU mode: {cpu_mode} not supported.")
        sys.exit(-1)


def init_context_handler():
    global handler
    if "handler" not in globals():
        handler = ContextHandler(Context())


class Context:
    def __init__(self):
        self.regs_name = []
        self.seg_regs_name = ["cs", "ds", "es", "fs", "gs", "ss"]
        self.regs = {}
        self.eflags_tbl = {
            0: "carry",
            2: "parity",
            4: "auxiliary",
            6: "zero",
            7: "sign",
            8: "trap",
            9: "interrupt",
            10: "direction",
            11: "overflow",
            14: "nested",
            16: "resume",
            17: "virtualx86",
        }
        self.is_changed = {}
        self.bp_name = ""
        self.bp = None
        self.sp_name = ""
        self.sp = None
        self.pc_name = ""
        self.pc = None

        self.init_regs_name()
        self.init_regs()

    def init_regs_name(self):
        if ARCH == "x86":
            self.regs_name = [
                "eax",
                "ebx",
                "ecx",
                "edx",
                "edi",
                "esi",
                "ebp",
                "esp",
                "eip",
            ]
            self.bp_name = "ebp"
            self.sp_name = "esp"
            self.pc_name = "eip"
        else:
            self.regs_name = [
                "rax",
                "rbx",
                "rcx",
                "rdx",
                "rdi",
                "rsi",
                "r8",
                "r9",
                "r10",
                "r11",
                "r12",
                "r13",
                "r14",
                "r15",
                "rbp",
                "rsp",
                "rip",
            ]
            self.bp_name = "rbp"
            self.sp_name = "rsp"
            self.pc_name = "rip"

    def init_regs(self):
        for reg_name in self.regs_name + self.seg_regs_name:
            self.regs[reg_name] = None
            self.is_changed[reg_name] = False

    def update_regs(self):
        for reg_name in self.regs_name + self.seg_regs_name:
            reg_data = dbgeng.get_register(reg_name)
            if reg_data != self.regs[reg_name]:  # is changed
                self.is_changed[reg_name] = True
            else:
                self.is_changed[reg_name] = False

            self.regs[reg_name] = reg_data
        # update bp & sp & pc
        self.bp = self.regs[self.bp_name]
        self.sp = self.regs[self.sp_name]
        self.pc = self.regs[self.pc_name]


class ContextHandler(dbgeng.eventHandler):
    def __init__(self, context):
        dbgeng.eventHandler.__init__(self)
        self.context = context

    def need_update_regs(func):
        @wraps(func)
        def wrap(*args, **kwargs):
            args[0].context.update_regs()
            func(*args, **kwargs)

        return wrap

    # Print register context
    @need_update_regs
    def print_regs(self):
        self.print_general_regs()
        self.print_seg_regs()
        self.print_eflags()

    def print_general_regs(self):
        for reg_name in self.context.regs_name:
            reg_data = self.context.regs[reg_name]
            reg_str = "{:3}: ".format(reg_name.upper())
            reg_color = self.set_reg_color(
                reg_name, color_changed=color.dark_red, color_unchanged=color.normal
            )
            logging.info_ec(reg_color(reg_str), False)

            if dbgeng.isValidVA(reg_data):  # reg_data is a pointer
                self.print_ptrs(reg_data)
            else:
                logging.info_ec("{:#x}".format(reg_data))

    def print_seg_regs(self):
        first_print = True
        for reg_name in self.context.seg_regs_name:
            reg_data = self.context.regs[reg_name]
            reg_str = "{:2}={:#x}".format(reg_name.upper(), reg_data)
            reg_color = self.set_reg_color(
                reg_name, color_changed=color.dark_red, color_unchanged=color.green
            )

            if first_print:
                logging.info_ec(reg_color(reg_str), False)
                first_print = False
            else:
                logging.info_ec(" | " + reg_color(reg_str), False)
        logging.info_ec("")

    def print_eflags(self):
        eflags = dbgeng.get_register("efl")
        eflags_str = color.green("EFLAGS: {:#x}".format(eflags))
        eflags_str += " ["
        for bit, flag_name in self.context.eflags_tbl.items():
            is_set = eflags & (1 << bit)
            eflags_str += " "
            if is_set:
                eflags_str += color.dark_red(flag_name)
            else:
                eflags_str += color.green(flag_name)
        eflags_str += " ]"
        logging.info_ec(eflags_str)

    def set_reg_color(self, reg_name, color_changed, color_unchanged):
        if self.context.is_changed[reg_name]:
            return color_changed
        else:
            return color_unchanged

    # Print assembly code
    def print_code(self):
        pc = self.context.pc
        for offset in range(-3, 6):  # pc-3 ~ pc+5
            addr = dbgeng.find_offset(offset)
            op_str, asm_str = dbgeng.disasm(addr)
            code_str = "{:#x}: {:20s}{}".format(addr, op_str, asm_str)
            if addr == pc:  # current pc, highlight
                logging.info_ec(color.highlight(code_str))
            else:
                logging.info_ec(code_str)

    # Print stack context
    @need_update_regs
    def print_stack(self):
        self.print_nline_ptrs(self.context.sp, config.ec_sc_lines)

    @need_update_regs
    def print_nline_ptrs(self, start_addr, line_num):
        for i in range(line_num):
            addr = start_addr + i * PTRSIZE
            if not dbgeng.isValidVA(addr):
                logging.error_ec("Invalid memory address: {:#x}".format(addr))
                break
            else:
                self.print_ptrs(addr)

    def print_ptrs(self, addr):
        ptrs_str = ""
        ptr_values, is_cyclic = self.smart_dereference(addr)
        # print all ptrs except last two
        for ptr in ptr_values[:-2:]:
            ptrs_str += "{:#x} --> ".format(ptr)
        # handle last two's format
        last_ptr, last_val = ptr_values[-2], ptr_values[-1]
        if is_cyclic:
            ptrs_str += "{:#x} --> {:#x}".format(last_ptr, last_val) + color.dark_red(
                " ( cyclic dereference )"
            )
        else:
            ptrs_str += self.enhance_type(last_ptr, last_val)
        logging.info_ec(ptrs_str)

    def enhance_type(self, ptr, val):
        ret_str = ""
        if dbgeng.is_executable(ptr):  # code page
            symbol = dbgeng.find_symbol(ptr)
            asm_str = dbgeng.disasm(ptr)[1]
            ret_str = "{:#x}".format(ptr)
            ret_str += color.normal(" ({} :      {})".format(symbol, asm_str))
        else:
            ret_str = "{:#x} --> {:#x}".format(ptr, val)
            val_str = dbgeng.get_string(ptr)
            if val_str:  # val is probably a string
                ret_str += color.normal(' ("{}")'.format(val_str))
        return ret_str

    def smart_dereference(self, ptr):
        ptr_values, is_cyclic = [ptr], False
        for _ in range(MAX_DEREF):
            val = dbgeng.deref_ptr(ptr)
            if val == None:  # no more dereference
                break
            elif val in ptr_values[:-1:]:  # cyclic dereference
                ptr_values.append(val)
                is_cyclic = True
                break
            else:
                ptr_values.append(val)
                ptr = val

        return ptr_values, is_cyclic

    def switch_arch(self, machine_type):
        global ARCH, PTRMASK, PTRSIZE
        if machine_type == "x86":
            ARCH = "x86"
            PTRMASK = 0xFFFFFFFF
            PTRSIZE = 4
        elif machine_type == "x64":
            ARCH = "x64"
            PTRMASK = 0xFFFFFFFFFFFFFFFF
            PTRSIZE = 8
        else:
            logging.error_ec("Invalid machine type! Neither x86 or x64.")
        self.context.init_regs_name()
        self.context.init_regs()
