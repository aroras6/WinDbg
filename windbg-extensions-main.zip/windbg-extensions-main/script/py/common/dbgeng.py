import string
from typing import Optional

import pykd
from common import aop, context, logging

# These are internally used only. If pykd method return string, it is fine to use NoneAsEmptyStrProxy proxy.
__dbgeng = aop.LogProxy(pykd)
__dbgengEW = aop.ErrorWaiveProxy(__dbgeng)
__dbgengRT = aop.NoneAsEmptyStrProxy(__dbgengEW)

__dbgeng_disasm = aop.LogProxy(__dbgeng.disasm())

__logger = logging.getLogger(__name__)


def to_addr(val) -> Optional[int]:
    """Convert a value to a memory address"""
    addr = eval_expr(val)
    if addr and isValidVA(addr):
        __logger.debug(f"Valid address [{hex(addr)}]")
        return addr & context.PTRMASK
    else:
        __logger.debug(f"Invalid address [{addr}]")
        return None


def get_address(symbol) -> Optional[str]:
    res = exec_command(f"x {symbol}")
    result_count = res.count("\n")
    if result_count == 0:
        __logger.debug(f"Symboal [{symbol}] not found.")
        return None
    if result_count > 1:
        __logger.debug(f"More than one result found for symbol [{symbol}].")
    return res.split()[0]


def check_valid_addr(val):
    """Check if val is valid memory address"""
    addr, real_val = to_addr(val), eval_expr(val)
    if not addr:
        errmsg = "Invalid address: "
        if real_val != None:
            errmsg += "{:#x}".format(real_val & context.PTRMASK)
        else:
            errmsg += "{}".format(val)
        return False, errmsg
    else:
        return True, None


def disasm(addr):
    """disassemble, return opcodes and  assembly string"""
    resp = __dbgeng_disasm.disasm(addr).split(" ")
    op_str = resp[1]
    asm_str = " ".join(c for c in resp[2::]).strip()
    return op_str, asm_str


def find_offset(offset):
    return __dbgeng_disasm.findOffset(offset)


def is_executable(addr):
    if __dbgeng.isKernelDebugging():
        return False  # we need to find a way to get the memory protection information in kernel debug mode
    if "Execute" in str(__dbgeng.getVaProtect(addr)):
        return True
    else:
        return False


def load_str(load_str_func, ptr):
    """Load string with dbgeng function"""
    max_length = 60

    s = load_str_func(ptr)
    if not all(c in string.printable for c in s):
        return None
    if len(s) > max_length:
        return s[:max_length:] + "..."
    else:
        return s


def deref_ptr(ptr):
    ptrs = read_ptr_list(ptr, 1)
    if ptrs and len(ptrs) > 0:        
        return ptrs[0] & context.PTRMASK
    else:
        # loadPtrs (args: (8388357042652472396, 1), kwargs: {})
        # Error: Memory exception at 0x74696e497072644c target virtual address
        return None


def set_alias(a, v):
    exec_command("as {} {}".format(a, v))


def get_cpu_mode(*args, **kwargs):
    cpu_mode = __dbgeng.getCPUMode(*args, **kwargs)
    if cpu_mode == pykd.CPUType.I386:
        return CPUType.I386

    if cpu_mode == pykd.CPUType.AMD64:
        return CPUType.AMD64

    # other cpu?
    return cpu_mode


def get_string(ptr):
    """try to get string from a pointer"""

    ret = load_str(read_wchar_str, ptr)  # try load WString (unicode) first
    if not ret:
        ret = load_str(read_char_str, ptr)  # if failed, load CStr ( ascii )

    return ret


############################################### Extends classes ##################################################
class CPUType(pykd.CPUType):
    pass


class eventHandler(pykd.eventHandler):
    pass


class eventResult(pykd.eventResult):
    pass


######################################## Wrap the APIs directly (No throw) ########################################
def exec_command(*args, **kwargs) -> str:
    """Execute Windbg command, i.e. dt, dx, etc"""
    return __dbgengRT.dbgCommand(*args, **kwargs)


def eval_expr(*args, **kwargs):
    """
    Evaluate a windbg expression, i.e. ? expr

    For number expr, the value returns in base 10.
    """
    return __dbgengEW.expr(*args, **kwargs)


def isValidVA(*args, **kwargs):
    return __dbgengEW.isValid(*args, **kwargs)


def find_symbol(*args, **kwargs):
    return __dbgengRT.findSymbol(*args, **kwargs)


def get_register(*args, **kwargs):
    return __dbgengEW.reg(*args, **kwargs)


def get_module(*args, **kwargs):
    return __dbgengEW.module(*args, **kwargs)


def load_doubles(*args, **kwargs):
    return __dbgengEW.loadDoubles(*args, **kwargs)


def dt_var(*args, **kwargs):
    """Return typed variable, it is the same as "dt <type> <ptr>"."""
    return __dbgengEW.typedVar(*args, **kwargs)


def dt_var_array(*args, **kwargs):
    """Return typed variable as array"""
    return __dbgengEW.typedVarArray(*args, **kwargs)


def set_breakpoint(*args, **kwargs):
    return __dbgengEW.setBp(*args, **kwargs)


def remove_breakpoint(*args, **kwargs):
    return __dbgengEW.removeBp(*args, **kwargs)


def read_ptr_value(*args, **kwargs):
    return __dbgengEW.ptrPtr(*args, **kwargs)


def read_ptr_list(*args, **kwargs):
    return __dbgengEW.loadPtrs(*args, **kwargs)


def read_word_value(*args, **kwargs):
    return __dbgengEW.ptrMWord(*args, **kwargs)


def read_wchar_str(*args, **kwargs):
    return __dbgengRT.loadWStr(*args, **kwargs)


def read_char_str(*args, **kwargs):
    return __dbgengRT.loadCStr(*args, **kwargs)


def go(*args, **kwargs):
    return __dbgengEW.go(*args, **kwargs)
