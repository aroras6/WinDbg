"""
It defines the constants.
"""

WINDBG_EXT_EC = "!ec"
WINDBG_EXT_MONA = "!mona"

# Python environments
EC_PYENV_PETREE = "petree"
EC_PYENV_MINIDUMP = "minidump"
EC_PYENV_VOLATILITY3 = "volatility3"
EC_PYENV_VISUALIZATION = "visualization"
EC_PYENV_GEODESY = "geodesy"

# OS environments
ENV_CSMAP_CWD = "CSMAP_CWD"