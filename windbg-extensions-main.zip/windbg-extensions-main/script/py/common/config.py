"""
The configurations.
"""

# Global verbose flag. This configuration doesn't impact the final verbose output, instead the command '-v' option.
verbose = False

# Command verbose flag.
verbose_cmd = False

# EC working folder name
ec_cwd = ".windbg_ec"

# The number of lines printed by sc command. e.g. 0n10
ec_sc_lines = 10