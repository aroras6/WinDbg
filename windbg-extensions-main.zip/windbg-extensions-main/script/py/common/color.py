"""
It defines the colors in Windbg.

See https://learn.microsoft.com/en-us/windows-hardware/drivers/debugger/customizing-debugger-output-using-dml
"""
NORMAL = ("normfg", "normbg")
RED = ("srcchar", "wbg")
BLUE = ("srcdrct", "wbg")
DARK_RED = ("changed", "wbg")
GREEN = ("srccmnt", "wbg")
PURPLE = ("srcannot", "wbg")
HIGHLIGHT = ("clfg", "clfg")


def normal(content: object):
    return colorize(NORMAL, content)


def highlight(content: object):
    return colorize(HIGHLIGHT, content)


def red(content: object):
    return colorize(RED, content)


def blue(content: object):
    return colorize(BLUE, content)


def dark_red(content: object):
    return colorize(DARK_RED, content)


def green(content: object):
    return colorize(GREEN, content)


def purple(content: object):
    return colorize(PURPLE, content)


def colorize(col: tuple, content: object):
    return '<col fg="{}" bg="{}">{}</col>'.format(col[0], col[1], content)
