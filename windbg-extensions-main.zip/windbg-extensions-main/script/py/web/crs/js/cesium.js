function getMapServerImageryProvider() {
    const esri = new Cesium.ArcGisMapServerImageryProvider({
        url: 'https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer',
    });

    return esri;
}

function getViewerProps() {
    return {
        imageryProvider: getMapServerImageryProvider(),

        orderIndependentTranslucency: false,
        selectionIndicator: false,
        baseLayerPicker: false,
        geocoder: false,
        homeButton: false,
        sceneModePicker: false,
        navigationHelpButton: false,
        animation: false,
        timeline: false,
        fullscreenButton: true,
        vrButton: false,
        shadows: true,
        infoBox: false,
    };
}

function showDetials(param) {
    let detailsPanel = document.getElementById('detailsPanel');
    if (!detailsPanel) return;

    if (!(param && param.size)) {
        detailsPanel.parentNode.parentNode.parentNode.style.display = 'none';
        return;    
    }    

    let table = document.createElement('table');

    Array.from(param).map(([key, value]) => {
        let tr = document.createElement('tr');

        let td1 = document.createElement('td');
        let td2 = document.createElement('td');

        let text1 = document.createTextNode(decodeURIComponent(key));
        let text2 = document.createTextNode(decodeURIComponent(value));

        td1.appendChild(text1);
        td1.style.padding = '0px 26px 0px 0px';
        td1.style.width = '130px';
        td2.appendChild(text2);
        td2.setAttribute('title', decodeURIComponent(value));
        td2.style.width = '260px';
        td2.style.display = 'inline-block';
        td2.style.whiteSpace = 'nowrap';        
        td2.style.overflow = 'hidden';
        td2.style.textOverflow = "ellipsis";      
        tr.appendChild(td1);
        tr.appendChild(td2);

        table.appendChild(tr);
    });

    detailsPanel.appendChild(table);
}

const toDegrees = Cesium.Math.toDegrees;
const toRadians = Cesium.Math.toRadians;

////////////////////////////////////////// Entities & Primitives /////////////////////////////////////////

function ellipsoid(name, radiusX, radiusY, radiusZ, position, orientation, attr) {
    const entity = viewer.entities.add({
        name: name,
        position: position || Cesium.Cartesian3.ZERO,
        ellipsoid: {
            radii: new Cesium.Cartesian3(radiusX, radiusY, radiusZ),
            material: Cesium.Color.YELLOW,
            ...attr,
        },
        orientation: orientation,
        label: {
            text: name,
        },
    });

    return entity;
}

function spheroid(name, semiMajor, semiMinor, position, orientation, attr) {
    return ellipsoid(name, semiMajor, semiMajor, semiMinor, position, orientation, attr);
}

function sphere(name, radius, position, orientation, attr) {
    return ellipsoid(name, radius, radius, radius, position, orientation, attr);
}

function globe_geoid() {
    const hpr = getHeadingPitchRoll(0, 0, 0);
    const orientation = new Cesium.ConstantProperty(
        Cesium.Transforms.headingPitchRollQuaternion(Cesium.Cartesian3.ZERO, hpr),
    );

    const datum = viewer.entities.add({
        name: 'geoid globe',
        position: new Cesium.Cartesian3(1500000, 0, 0),
        model: {
            uri: '\\\\aiwshare\\AIM\\Transfer\\Caelum\\CsMap\\geoid\\geoid.glb',
            minimumPixelSize: 100000,
            maximumScale: 163200,
            scale: 1,
        },
        orientation: orientation,
    });
    return datum;
}

function geodetic_datum_wgs84(globe) {
    return geodetic_datum('WGS84 datum', globe.ellipsoid.radii.x, globe.ellipsoid.radii.z);
}

function geodetic_datum(name, semiMajor, semiMinor, position, orientation, color, attr) {
    const datum = spheroid(name, semiMajor, semiMinor, position, orientation, {
        fill: false,
        outline: true,
        outlineColor: color || Cesium.Color.YELLOW,
        slicePartitions: 24,
        stackPartitions: 36,
        ...attr,
    });
    datum.label.scaleByDistance = new Cesium.NearFarScalar(6.0e6, 3.0, 8.0e6, 0.0);

    return datum;
}

function parallel(latitude, color, granularity) {
    const name = `Parallel ${latitude}`;
    return viewer.entities.add({
        name: name,
        polyline: {
            positions: Cesium.Cartesian3.fromDegreesArray([
                -180,
                latitude,
                -90,
                latitude,
                0,
                latitude,
                90,
                latitude,
                180,
                latitude,
            ]),
            width: 2,
            arcType: Cesium.ArcType.RHUMB,
            material: color,
            granularity: granularity,
        },
    });
}

function meridian(longitude, color, granularity) {
    const name = `Meridian ${longitude}`;
    return viewer.entities.add({
        name: name,
        polyline: {
            positions: Cesium.Cartesian3.fromDegreesArray([longitude, 90, longitude, 0, longitude, -90]),
            width: 2,
            arcType: Cesium.ArcType.RHUMB,
            material: color,
            granularity: granularity,
        },
    });
}

function labelCoordinates(cartographic, ...other_cartographices) {
    const position = Cesium.Cartographic.toCartesian(cartographic);  
    const latitude = toDegrees(cartographic.latitude).toFixed(4);
    const longitude = toDegrees(cartographic.longitude).toFixed(4);
    const height = cartographic.height.toFixed(4);
    let label = `lat: ${latitude}° lon: ${longitude}° height: ${height}`;

    for (const other_cartographic of other_cartographices) {
        const other_latitude = toDegrees(other_cartographic.latitude).toFixed(4);
        const other_longitude = toDegrees(other_cartographic.longitude).toFixed(4);
        const other_height = other_cartographic.height.toFixed(4);

        label += `\n`;
        label += `lat: ${other_latitude}° lon: ${other_longitude}° height: ${other_height}`;
    }

    return viewer.entities.add({
        position: position,
        label: {
            text: label,
            height: 100,
            showBackground: false,
            font: '20px monospace',
            horizontalOrigin: Cesium.HorizontalOrigin.LEFT,
            verticalOrigin: Cesium.VerticalOrigin.TOP,
            pixelOffset: new Cesium.Cartesian2(15, 0),
            fillColor: Cesium.Color.WHITE,
        },
    });
}

function primitive_axes(length, position, hpr, scale) {
    // The X axis is red; Y is green; and Z is blue.
    const axes = new Cesium.DebugModelMatrixPrimitive({
        modelMatrix: getTranslationRotateScaleMatrix(position, hpr, scale),
        length: length,
        width: 2.0,
    });

    return axes;
}

function markerCoordinates(cartographic) {        
    return viewer.entities.add({
        name: 'marker',
        position: Cesium.Cartographic.toCartesian(cartographic),
        billboard: {
            image: 'images/marker.png',
            verticalOrigin: Cesium.VerticalOrigin.BOTTOM,
        },
    });
}

function cs_extent(csName, semiMajor, semiMinor, position, orientation, csExtent) {
    const name = `the extent of ${csName}`;

    if (!isExtentValid(csExtent)) return;

    const extent = viewer.entities.add({
        name: name,
        position: position || Cesium.Cartesian3.ZERO,
        orientation: orientation,
        ellipsoid: {
            radii: new Cesium.Cartesian3(semiMajor, semiMajor, semiMinor),
            minimumClock: toRadians(csExtent.minLon),
            maximumClock: toRadians(csExtent.maxLon),
            minimumCone: toRadians(90 - csExtent.minLat),
            maximumCone: toRadians(90 - csExtent.maxLat),
            material: Cesium.Color.YELLOW.withAlpha(0.8),
            outline: true,
            outlineColor: Cesium.Color.YELLOW,
        },
    });
    return extent;
}

////////////////////////////////////////////////// functions //////////////////////////////////////////////////////

function getTranslationRotateScaleMatrix(translation, hpr, scale) {
    const quaternion = Cesium.Transforms.headingPitchRollQuaternion(Cesium.Cartesian3.ZERO, hpr);
    const matrix = Cesium.Matrix4.fromTranslationQuaternionRotationScale(
        translation,
        quaternion,
        new Cesium.Cartesian3(scale, scale, scale),
    );

    return matrix;
}

function getHeadingPitchRoll(heading, pitch, roll) {
    const h = Cesium.Math.RADIANS_PER_ARCSECOND * heading + Cesium.Math.RADIANS_PER_DEGREE * 90; // adjust ceisum axes to match the geodesy definition.
    const p = Cesium.Math.RADIANS_PER_ARCSECOND * pitch;
    const r = Cesium.Math.RADIANS_PER_ARCSECOND * roll;
    const hpr = new Cesium.HeadingPitchRoll(h, p, r);

    return hpr;
}

function toScale(bwscale) {
    return 1 + bwscale * 1.0e-6; //CS_parm7.c
}

function isExtentValid(extent) {
    let { minLon, minLat, maxLon, maxLat } = extent;
    return minLon && minLat && maxLon && maxLat;
}
