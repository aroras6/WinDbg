from command_common import *


@arg_parser(None)
def r(args):
    """Display the register context"""
    context.handler.print_regs()


@arg_parser(None)
def sc(args):
    """Display the stack memory content"""
    context.handler.print_stack()


@arg_parser(
    # fmt: off
    lambda parser: (            
        parser.add_argument("addr", help="the address of the memory"),
        parser.add_argument("lines", default="0x8", nargs="?", help="the number of lines")
    )
    # fmt: on
)
def mc(args):
    """Display memory content at an address with smart dereferences

    Usage: !ec mc [addr] [line to display, default=0n8, maximum=0n100]
    """
    # get start address and line number
    start_addr = dbgeng.to_addr(args.addr)
    line_num = dbgeng.eval_expr(args.lines)
    # check valid address
    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(errmsg)
    # check valid line number
    if not check_in_range(line_num, 1, 100):
        raise CmdExecError(f"Invalid line number: {args.lines}, should be 0n1 ~ 0n100")

    context.handler.print_nline_ptrs(start_addr, line_num)


@arg_parser(lambda parser: parser.add_argument("arch", default="x64", nargs="?", choices=["x64", "x86"], help="the arch of the cpu"))
def switch_arch(args):
    """
    Switch machine type for current debugging session
    Usage: !ec switch_arch [x86|x64]
    """
    context.handler.switch_arch(args.arch)


"""
Register command at global.
"""
register_ec_command(__file__, r)
register_ec_command(__file__, sc)
register_ec_command(__file__, mc)
register_ec_command(__file__, switch_arch)
