"""
The commands for analyzing memory dumps.

The 3rd party tools used are as below:
    minidump - https://github.com/skelsec/minidump    
"""
from command_common import *


@arg_parser(None)
def minidump(args):
    """Dump information of Microsoft Mini dumps

    Examples:
        // Show header info of Microsoft mini dump
        !ec minidump --header <mindidump file>

    Note: Do NOT run with "-i", use minidumpshell instead for interactive mode.
    """
    cmd_line = f"minidump {' '.join(args)}"
    runPipenv(cmd_line, consts.EC_PYENV_MINIDUMP)


@arg_parser(None)
def minidumpshell(args):
    """Launch minidump shell

    Examples:
        !ec minidumpshell <mindidump file>
    """

    cmd_line = f"minidump -i {' '.join(args)}"
    runPipenvInteract(cmd_line, consts.EC_PYENV_MINIDUMP)


"""
Register command at global.
"""
register_ec_command(__file__, minidump)
register_ec_command(__file__, minidumpshell)
