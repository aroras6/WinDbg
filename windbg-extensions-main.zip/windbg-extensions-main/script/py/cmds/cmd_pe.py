"""
The commands for Windows portable executables.

The 3rd party tools are as below:
    pe_tree - PE Tree is a Python module for viewing Portable Executable (PE) files in a tree-view using pefile and PyQt5. see https://github.com/blackberry/pe_tree for more details.
    minidump - It needs to be installed in local pip environment, see https://github.com/skelsec/minidump for more details.    
"""
from command_common import *


@arg_parser(lambda parser: parser.add_argument("filename", help="Path(s) to file/folder/zip"))
def pe_tree(args):
    """PE Tree that scans for portable executables in files, folders and ZIP archives"""

    cmd_line = f"pe-tree {args.filename}"
    runPipenvDetach(cmd_line, consts.EC_PYENV_PETREE)


@arg_parser(lambda parser: parser.add_argument("filename", help="Path to file to carve"))
def pe_tree_carve(args):
    """PE Tree that attempts to carve portable executable files from a binary file"""

    cmd_line = f"pe-tree-carve {args.filename}"
    runPipenvDetach(cmd_line, consts.EC_PYENV_PETREE)


@arg_parser(lambda parser: parser.add_argument("filename", help="Path to .dmp file"))
def pe_tree_minidump(args):
    """PE Tree Minidump plugin finds portable executables in Windows Minidumps"""

    cmd_line = f"pe-tree-minidump {args.filename}"
    runPipenvDetach(cmd_line, consts.EC_PYENV_PETREE)


@arg_parser(
    # fmt: off
     lambda parser: (            
        parser.add_argument("-vm", action="store_true", help="indicate if the memory dump should be opened, otherwise PE image by default."),
        parser.add_argument("-m", "--module", required=True, help="the module name"),        
    )
    # fmt: on)
)
def show_module_pe(args):
    """
    Dump module's portable executable (PE) to current working folder and open it by pe-tree

    It can also dump the module's meomory to current working folder and open it by pe-tree.

    Some drivers sections are discardable (they are mapped when the control flow reaches the entry but will be unmapped,
    usually after the DriverEntry execution) and other sections will be paged out (written to disk) by the system during
    the driver's life (and mapped back in case of a page fault). Also, (iirc) .writemem fails entirely if it can't read a
    portion of the memory range.  Your best bet is to dump the driver at the entry point (I think Windows doesn't lazy
    load driver sections).

    Technically, you can loop around all pages and if one is missing you can try to .pagein the missing block(s), but it
    happens to fail sometimes too (without any means to know why)...

    .pagein is quite fiddly as you ask for a page range so the debugger can page in the requested memory from disk, but you
    also need to have the system run (.pagein needs to be followed by a g) so the filesystem driver stack can be asked by the
    debugger to actually get back the pages into memory. During that time, the system runs...

    If you're doing this on a memory dump, you can't obviously .pagein so it won't work; you'll need a live system.

    Example:
        !ec show_module_pe -m AeccRoadway
    """
    module_name = args.module

    logging.info_ec(f"Retrieving infomation of module [{module_name}]...")
    module = dbgeng.get_module(module_name)

    if not module:
        logging.error_ec(f"Failed to find the module {module_name}")
        return

    if not args.vm:
        image = module.image()
        if pathExists(image):
            pe_tree([image])
            return
        else:
            pdb = module.symfile()
            if pdb and pathExists(pdb):
                guessImage = f"{parentFolder(pdb)}\{image}"
                if pathExists(guessImage):
                    pe_tree([guessImage])
                    return

                for suffix in ["", ".dll", ".exe"]:
                    guessImage = f"{parentFolder(pdb)}\{module_name}{suffix}"
                    if pathExists(guessImage):
                        pe_tree([guessImage])
                        return

        logging.error_ec(f"No portable executable found for module [{module_name}].")

    else:
        temp_pe = f"{getWorkingFolder()}\{getRandomFilename()}"
        dbgeng.exec_command(f".writemem {temp_pe} {hex(module.begin())} L?{hex(module.size())}")
        pe_tree([temp_pe])
        return


"""
Register command at global.
"""
register_ec_command(__file__, pe_tree)
register_ec_command(__file__, pe_tree_carve)
register_ec_command(__file__, pe_tree_minidump)
register_ec_command(__file__, show_module_pe)
