from command_common import *


# fmt: off
@arg_parser(None)
def diagram_stack_enter_exit(args):
    """Print stack layout diagram with enter and exit statements
    """
    logging.info_ec("------------------------------ Stack Layout--------------------------------------")
    logging.info_ec("")
    logging.info_ec("")
    logging.info_ec("           Low            |====================|                                 ")
    logging.info_ec("           addresses      | Unused space       |                                 ")
    logging.info_ec("                          |                    |                                 ")
    logging.info_ec("                          |====================|    ← RSP points here            ")
    logging.info_ec("              ↑           | Function's         |                                 ")
    logging.info_ec("              ↑           | local variables    |                                 ")
    logging.info_ec("              ↑           |                    |    ↑ RBP - x                    ")
    logging.info_ec("           direction      |--------------------|    ← RBP points here            ")
    logging.info_ec("           of stack       | Original/saved RBP |    ↓ RBP + x                    ")
    logging.info_ec("           growth         |--------------------|                                 ")
    logging.info_ec("              ↑           | Return pointer     |                                 ")
    logging.info_ec("              ↑           |--------------------|                                 ")
    logging.info_ec("              ↑           | Function's         |                                 ")
    logging.info_ec("                          | parameters         |                                 ")
    logging.info_ec("                          |                    |                                 ")
    logging.info_ec("                          |====================|                                 ")
    logging.info_ec("                          | Parent             |                                 ")
    logging.info_ec("                          | function's data    |                                 ")
    logging.info_ec("                          |====================|                                 ")
    logging.info_ec("                          | Grandparent        |                                 ")
    logging.info_ec("           High           | function's data    |                                 ")
    logging.info_ec("           addresses      |====================|                                 ")
    logging.info_ec("")
    logging.info_ec("        ----------------------------------------------------------               ")
    logging.info_ec("        | push   %rbp                                            |               ")
    logging.info_ec("        | mov    %rsp, %rbp                                      |               ")
    logging.info_ec("        |                                                        |               ")
    logging.info_ec("        | This first instruction saves the original value of     |               ")
    logging.info_ec("        | RBP by pushing it onto the stack, and then the second  |               ")
    logging.info_ec("        | instruction sets RBP to the original value of RSP.     |               ")
    logging.info_ec("        ----------------------------------------------------------               ")
    logging.info_ec("")
    logging.info_ec("        ----------------------------------------------------------               ")
    logging.info_ec("        | mov    %rbp, %rsp                                      |               ")
    logging.info_ec("        | pop    %rbp                                            |               ")
    logging.info_ec("        |                                                        |               ")
    logging.info_ec("        | This first instruction sets RSP to the value of RBP (  |               ")
    logging.info_ec("        | the working value used throughout the function's code),|               ")
    logging.info_ec("        | and the second instruction pops the                    |               ")
    logging.info_ec("        | 'original/saved RBP' off the stack, into RBP.          |               ")
    logging.info_ec("        ----------------------------------------------------------               ")
    logging.info_ec("")
    logging.info_ec("---------------------------------------------------------------------------------")


@arg_parser(None)
def diagram_register_backward(args):
    """Print register backward compatibility diagram
    """
    logging.info_ec("")
    logging.info_ec("        |__64__|__56__|__48__|__40__|__32__|__24__|__16__|__8___|               ")
    logging.info_ec("        |__________________________RAX__________________________|               ")
    logging.info_ec("        |xxxxxxxxxxxxxxxxxxxxxxxxxxx|____________EAX____________|               ")
    logging.info_ec("        |xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx|_____AX______|               ")
    logging.info_ec("        |xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx|__AH__|__AL__|               ")
    logging.info_ec("")
# fmt: on


@arg_parser(None)
def diagram_stack_layout(args):
    """Show x64 stack layout"""
    show_image(f"{getKnowledgeManagementFolder()}\stack_layout.webp")


"""
Register command at global.
"""
register_ec_command(__file__, diagram_stack_layout)
register_ec_command(__file__, diagram_stack_enter_exit)
register_ec_command(__file__, diagram_register_backward)
