from command_common import *
from common import math_geo
from math import sqrt


@arg_parser(None)
def csmap(args):
    """The csmap command line interface (cli)"""

    __runCsMap(args)


@arg_parser(lambda parser: parser.add_argument("any", nargs=argparse.REMAINDER))
def show_globe(args):
    """Show globe earth

    It contains following visulaization features:
    1. Projection of coordinate reference system
    2. Show equator
    3. Show prime meridian
    4. etc

    """
    show_html(f"{getWebResourceFolder()}\crs\earth.html")


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("addr", nargs="?", help="the address of a geodetic datum (struct cs_Datum_)"),
        parser.add_argument("-t", "--type", type=int, default=0, choices={0: 'from definition', 1: 'from caculation'}, metavar='', help="indicates how are the datum shift parameters figured out (default: %(default)s). Options: %(ec_choices)s"),
    )
    # fmt: on
)
def show_geodetic_datum(args):
    """Show datum of the geodetic coordinate reference system"""

    params = {}

    if args.addr:
        is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
        if not is_addr:
            raise CmdExecError(f"Not a valid address of geodetic datum. Error: [{errmsg}]")

        datum = dbgeng.dt_var("cs_Datum_", dbgeng.to_addr(args.addr))
        dtname = dbgeng.get_string(datum.key_nm)

        calculated = False
        if args.type == 1:
            logging.info_ec("Calculating the tranlation-rotation-scale matrix for 7 parameteres transformation")
            oab, rot, scale = calculateToWGS84Matrix(dtname, datum.e_rad)

            calculated = True
        else:
            logging.info_ec("Fetching the tranlation-rotation-scale matrix from datum definition for 7 parameteres transformation")

        params = {
            "e_rad": float(datum.e_rad),
            "p_rad": float(datum.p_rad),
            "flat": float(datum.flat),
            "eccentricity": float(datum.ecent),
            "dX": float(oab[0] if calculated else datum.delta_X),
            "dY": float(oab[1] if calculated else datum.delta_Y),
            "dZ": float(oab[2] if calculated else datum.delta_Z),
            "rX": float(rot[0] if calculated else datum.rot_X),
            "rY": float(rot[1] if calculated else datum.rot_Y),
            "rZ": float(rot[2] if calculated else datum.rot_Z),
            "bwscale": float(scale if calculated else datum.bwscale),
            "dt_name": dbgeng.get_string(datum.key_nm),
            "el_name": dbgeng.get_string(datum.ell_knm),
            "dt_desc": dbgeng.get_string(datum.dt_name),
            "el_desc": dbgeng.get_string(datum.el_name),
        }

    logging.debug_ec(params)

    url = f"file:///{getWebResourceFolder()}\crs\datum.html?{to_html_param(params)}"
    logging.debug_ec(url)
    show_html(url)


@arg_parser(
    # fmt: off
    lambda parser: (
        parser.add_argument("addr", help="the address of a geodetic coordinate reference system (cs_Csprm_)"),
        parser.add_argument("-t", "--type", type=int, default=0, choices={0: 'from definition', 1: 'from caculation'}, metavar='', help="indicates how are the datum shift parameters figured out (default: %(default)s). Options: %(ec_choices)s"),
        parser.add_argument("-c", "--coord", type=str, metavar='', help="the coordinates (x,y,z)")
    )
    # fmt: on
)
def show_geodetic_cs(args):
    """Show geodetic coordinate reference system"""

    params = {}

    if args.addr:
        is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
        if not is_addr:
            raise CmdExecError(f"Not a valid address of geodetic coordinate reference system. Error: [{errmsg}]")

        csprm = dbgeng.dt_var("cs_Csprm_", dbgeng.to_addr(args.addr))
        dtname = dbgeng.get_string(csprm.datum.key_nm)

        calculated = False
        if args.type == 1:
            logging.info_ec("Calculating the tranlation-rotation-scale matrix for 7 parameteres transformation")
            oab, rot, scale = calculateToWGS84Matrix(dtname, csprm.datum.e_rad)
            calculated = True
        else:
            logging.info_ec("Fetching the tranlation-rotation-scale matrix from datum definition for 7 parameteres transformation")

        params = {
            "e_rad": float(csprm.datum.e_rad),
            "p_rad": float(csprm.datum.p_rad),
            "flat": float(csprm.datum.flat),
            "eccentricity": float(csprm.datum.ecent),
            "dX": float(oab[0] if calculated else csprm.datum.delta_X),
            "dY": float(oab[1] if calculated else csprm.datum.delta_Y),
            "dZ": float(oab[2] if calculated else csprm.datum.delta_Z),
            "rX": float(rot[0] if calculated else csprm.datum.rot_X),
            "rY": float(rot[1] if calculated else csprm.datum.rot_Y),
            "rZ": float(rot[2] if calculated else csprm.datum.rot_Z),
            "bwscale": float(scale if calculated else csprm.datum.bwscale),
            "cs_name": dbgeng.get_string(csprm.csdef.key_nm),
            "cs_desc": dbgeng.get_string(csprm.csdef.desc_nm),
            "dt_name": dbgeng.get_string(csprm.datum.key_nm),
            "dt_desc": dbgeng.get_string(csprm.datum.dt_name),
            "el_name": dbgeng.get_string(csprm.datum.ell_knm),
            "el_desc": dbgeng.get_string(csprm.datum.el_name),
            "minLon": float(csprm.min_ll[0]) + float(csprm.cent_mer),
            "minLat": float(csprm.min_ll[1]),
            "maxLon": float(csprm.max_ll[0]) + float(csprm.cent_mer),
            "maxLat": float(csprm.max_ll[1]),
            "cent_mer": float(csprm.cent_mer),
            "minLon (w/o cent_mer)": float(csprm.csdef.ll_min[0]),
            "minLat (w/o cent_mer)": float(csprm.csdef.ll_min[1]),
            "maxLon (w/o cent_mer)": float(csprm.csdef.ll_max[0]),
            "maxLat (w/o cent_mer)": float(csprm.csdef.ll_max[1]),
        }

        if args.coord:
            params.update({"coord (CsMap LL84)": str(toWGS84(params["cs_name"], args.coord)).lstrip("[").rstrip("]").replace(", ", ",")})
            params.update({"coord (Raw)": args.coord})

    logging.debug_ec(params)

    url = f"file:///{getWebResourceFolder()}\crs\datum.html?{to_html_param(params)}"
    logging.debug_ec(url)
    show_html(url)


@arg_parser(
    lambda parser: (
        parser.add_argument("addr", help="the address of a geodetic coordinate system (cs_Csprm_)"),
        parser.add_argument("-c", "--coord", type=str, metavar="", help="the coordinates (lng,lat)"),
    )
)
def show_geodetic_proj(args):
    """Show projection of projected coordinate reference system"""

    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Not a valid address of geodetic coordinate system. Error: [{errmsg}]")

    csprm = dbgeng.dt_var("cs_Csprm_", dbgeng.to_addr(args.addr))
    prj = dbgeng.get_string(csprm.csdef.prj_knm)

    if prj == "UTM":
        params = {
            "zone": int(csprm.csdef.prj_prm1),
            "southern_hemisphere": False if (float(csprm.csdef.prj_prm2) >= 0.0) else True,
        }

    elif prj == "TM":
        params = {
            "central_longitude": float(csprm.csdef.prj_prm1),
            "central_latitude": float(csprm.csdef.org_lat),
            "false_easting": float(csprm.csdef.x_off),
            "false_northing": float(csprm.csdef.y_off),
            "scale_factor": float(csprm.csdef.scl_red),
        }

    elif prj in ["AE", "LM", "EDCNC"]:
        params = {
            "central_longitude": float(csprm.csdef.org_lng),
            "central_latitude": float(csprm.csdef.org_lat),
            "false_easting": float(csprm.csdef.x_off),
            "false_northing": float(csprm.csdef.y_off),
            "standard_parallels": (float(csprm.csdef.prj_prm1), float(csprm.csdef.prj_prm2)),
        }

    elif prj == "AZMEA":
        params = {
            "central_longitude": float(csprm.csdef.org_lng),
            "central_latitude": float(csprm.csdef.org_lat),
            "false_easting": float(csprm.csdef.x_off),
            "false_northing": float(csprm.csdef.y_off),
        }

    elif prj in ["MOLLWEID", "ROBINSON", "SINUS"]:
        params = {
            "central_longitude": float(csprm.csdef.org_lng),
            "false_easting": float(csprm.csdef.x_off),
            "false_northing": float(csprm.csdef.y_off),
        }

    else:
        params = {}

    csname = dbgeng.get_string(csprm.csdef.key_nm)
    lng_min = float(csprm.csdef.ll_min[0])
    lat_min = float(csprm.csdef.ll_min[1])
    lat_max = float(csprm.csdef.ll_max[1])
    lng_max = float(csprm.csdef.ll_max[0])
    lng_mid = (lng_min + lng_max) / 2.0

    extent_x = []
    extent_y = []
    for l1, l2 in [(lng_min, lat_min), (lng_min, lat_max), (lng_mid, lat_max), (lng_max, lat_max), (lng_max, lat_min), (lng_mid, lat_min)]:
        coord = f"{l1},{l2}"
        succeeded, [x, y] = ll2xy(trg_prj=csname, coord=coord)
        if not succeeded:
            raise CmdExecError(f"Failed to transform the geographic coordinate [{coord}] of [{csname}] to its cartesian coordinate.")
        extent_x.append(x)
        extent_y.append(y)

    extent_x.append(extent_x[0])
    extent_y.append(extent_y[0])

    payload = {
        "name": csname,
        "projection": prj,
        "unit": dbgeng.get_string(csprm.csdef.unit),
        "params": params,
        "semimajor": float(csprm.datum.e_rad),
        "semiminor": float(csprm.datum.p_rad),
        "lng_min": float(csprm.csdef.ll_min[0]),
        "lat_min": float(csprm.csdef.ll_min[1]),
        "lng_max": float(csprm.csdef.ll_max[0]),
        "lat_max": float(csprm.csdef.ll_max[1]),
        "x_min": float(csprm.min_xy[0]),
        "x_max": float(csprm.max_xy[0]),
        "y_min": float(csprm.min_xy[1]),
        "y_max": float(csprm.max_xy[1]),
        "extent_x": extent_x,
        "extent_y": extent_y,
    }

    if args.coord:
        succeeded, [x, y] = ll2xy(trg_prj=csname, coord=args.coord)
        if not succeeded:
            raise CmdExecError(f"Failed to transform the geographic coordinate [{args.coord}] of [{csname}] to its cartesian coordinate.")
        payload.update({"coord(ll)": args.coord})
        payload.update({"coord(xy)": f"{x},{y}"})

    logging.debug_ec(payload)
    show_geodesy_map(" ".join([f'{key}="{value}"' for key, value in payload.items()]))


def __runCsMap(args, listener: LocalShellListener = None):
    if consts.ENV_CSMAP_CWD in os.environ:
        cwd = os.environ[consts.ENV_CSMAP_CWD]
        logging.debug_ec(f"Found env variable [{consts.ENV_CSMAP_CWD}] value [{cwd}]")
    else:
        logging.warn_ec(f"The environment variable [{consts.ENV_CSMAP_CWD}] is not defined.")

    csmap_exe = getFile(cwd, "csmap.exe")
    if not csmap_exe:
        logging.error_ec("csmap.exe not found.")

    cmd_line = f"{csmap_exe} {' '.join(args)}"
    logging.debug_ec(cmd_line)

    runShell(cmd_line, cwd, listener)


def gdt2gdt(src_gdt, trg_gdt, coord, type="2d", precision="8"):
    """Call csmap command to do geodetic datum transformation"""

    args_array = []
    args_array.append("gdt2gdt")
    args_array.append("-src_gdt")
    args_array.append(src_gdt)
    args_array.append("-trg_gdt")
    args_array.append(trg_gdt)
    args_array.append("-coord")
    args_array.append(coord)
    args_array.append("-type")
    args_array.append(type)
    args_array.append("-precision")
    args_array.append(precision)

    shell_listener = LocalShellListener(1)
    __runCsMap(args_array, shell_listener)

    def coordinates_parser(output):
        coordinates = output.split()
        if len(coordinates) == 3:
            x, y, z = coordinates
            if is_number(x) and is_number(y) and is_number(z):
                return True, [float(x), float(y), float(z)]

        return False, None

    return shell_listener.getResult(coordinates_parser)


def gcs2gcs(src_geo, trg_geo, coord, precision="8"):
    """Call csmap command to do geodetic coordinate system transformation"""

    args_array = []
    args_array.append("gcs2gcs")
    args_array.append("-src_geo")
    args_array.append(src_geo)
    args_array.append("-trg_geo")
    args_array.append(trg_geo)
    args_array.append("-coord")
    args_array.append(coord)
    args_array.append("-precision")
    args_array.append(precision)

    shell_listener = LocalShellListener(1)
    __runCsMap(args_array, shell_listener)

    def coordinates_parser(output):
        coordinates = output.split()
        if len(coordinates) == 3:
            x, y, z = coordinates
            if is_number(x) and is_number(y) and is_number(z):
                return True, [float(x), float(y), float(z)]

        return False, None

    return shell_listener.getResult(coordinates_parser)


def calculateRotationEulerAngles(oab, pxb, pyb):
    oabstr = ",".join(map(str, oab))
    pxbstr = ",".join(map(str, pxb))
    pybstr = ",".join(map(str, pyb))
    cmd_line = f"name=calculateRotationEulerAngles Oab={oabstr} Pxb={pxbstr} Pyb={pybstr}"

    shell_listener = LocalShellListener(1)
    execute_geodesy_util_method(cmd_line, shell_listener)

    def rotation_euler_angles_parser(output):
        euler_angles = str(output.strip().lstrip("[").rstrip("]")).split()
        if len(euler_angles) == 3:
            o, p, k = euler_angles
            if is_number(o) and is_number(p) and is_number(k):
                return True, [float(o), float(p), float(k)]

        return False, None

    return shell_listener.getResult(rotation_euler_angles_parser)


def calculateToWGS84Matrix(dtname, e_rad):
    conversion = math_geo.GeodesyCorrdinateSystemConversion()

    coord = f"0,0,{float(e_rad) * -1}"
    succeeded, llh = gdt2gdt(src_gdt=dtname, trg_gdt="WGS84", coord=coord, type="3d", precision="17")
    if not succeeded:
        raise CmdExecError(f"Failed to transform coordinate [{coord}] from [{dtname}] to [WGS84].")
    oab = conversion.geodetic_to_ecef(llh[1], llh[0], llh[2])

    coord = f"0,0,0"
    succeeded, llh = gdt2gdt(src_gdt=dtname, trg_gdt="WGS84", coord=coord, type="3d", precision="17")
    if not succeeded:
        raise CmdExecError(f"Failed to transform coordinate [{coord}] from [{dtname}] to [WGS84].")
    pxb = conversion.geodetic_to_ecef(llh[1], llh[0], llh[2])

    coord = f"90,0,0"
    succeeded, llh = gdt2gdt(src_gdt=dtname, trg_gdt="WGS84", coord=coord, type="3d", precision="17")
    if not succeeded:
        raise CmdExecError(f"Failed to transform coordinate [{coord}] from [{dtname}] to [WGS84].")
    pyb = conversion.geodetic_to_ecef(llh[1], llh[0], llh[2])

    succeeded, rot = calculateRotationEulerAngles(oab, pxb, pyb)
    if not succeeded:
        raise CmdExecError(f"Failed to calculate the rotation euler angles. oab [{oab}], pxb [{pxb}], pyb [{pyb}]")
    bwscale = sqrt((pxb[0] - oab[0]) ** 2 + (pxb[1] - oab[1]) ** 2 + (pxb[2] - oab[2]) ** 2) * 1.0e06 / float(e_rad) - 1.0e06

    return oab, rot, bwscale


def toWGS84(crs, coord):
    succeeded, llh = gcs2gcs(src_geo=crs, trg_geo="LL84", coord=coord)
    if not succeeded:
        raise CmdExecError(f"Failed to transform coordinate [{coord}] from [{crs}] to [LL84].")

    return llh


def ll2xy(trg_prj, coord, precision="8"):
    """Call csmap command to transform the longitude/latitude of a projected coordinate system to its cartesian coordinate."""

    args_array = []
    args_array.append("ll2xy")
    args_array.append("-trg_prj")
    args_array.append(trg_prj)
    args_array.append("-coord")
    args_array.append(coord)
    args_array.append("-precision")
    args_array.append(precision)

    shell_listener = LocalShellListener(1)
    __runCsMap(args_array, shell_listener)

    def coordinates_parser(output):
        coordinates = output.split()
        if len(coordinates) == 3:
            x, y, _ = coordinates
            if is_number(x) and is_number(y):
                return True, [float(x), float(y)]

        return False, None

    return shell_listener.getResult(coordinates_parser)


"""
Register command at global.
"""
register_ec_command(__file__, csmap)
register_ec_command(__file__, show_globe)
register_ec_command(__file__, show_geodetic_datum)
register_ec_command(__file__, show_geodetic_proj)
register_ec_command(__file__, show_geodetic_cs)
