from command_common import *


@arg_parser(lambda parser: parser.add_argument("addr", help="the address of a polyline"))
def c3d_show_ac_polyline(args):
    """Show AcDbPolyline according to either name or raw address

    Examples:
        !ec c3d_show_ac_polyline pline
        !ec c3d_show_ac_polyline 0xa0a5ffd0e0
    """
    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Not a valid address of polyline. Error: [{errmsg}]")
    else:
        polyline = dbgeng.dt_var("acdb24!AcDbPolyline", dbgeng.to_addr(args.addr))
        pImp = dbgeng.dt_var("acdb24!AcDbImpPolyline", polyline.mpImpObject)
        mBuf = dbgeng.dt_var("acdb24!AcDbPolylineBuffer", pImp.mBuf)
        numPoints = mBuf.mNumPointsUsed
        points = dbgeng.dt_var_array(mBuf.mpPoints, "acdb24!AcGePoint2d", int(numPoints))

        payload = []
        for pt in points:
            pt_coord = [float(pt.x), float(pt.y), 0.0]
            payload.append(pt_coord)

        path = dump_object(payload)
        if path:
            show_polyline(path)


@arg_parser(
    # fmt: off
    lambda parser: (            
        parser.add_argument("addr", help="the address of the AcDbObject instance"),
        parser.add_argument("type", default="asm", const="asm", nargs="?", choices=["asm", "bgc"], help="show by either BodyGraphicsCache or ASM ENTITY")
    )
    # fmt: on
)
def c3d_show_ac_object(args):
    """Show object that has the implementation of AcDbImpModelerGeometry according to either name or raw address

    Examples:
        !ec c3d_show_ac_object pSolid
        !ec c3d_show_ac_object pSolid bgc
    """
    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Not a valid address of AcDbEntity. Error: [{errmsg}]")
    else:
        obj = dbgeng.dt_var("acdb24!AcDbObject", dbgeng.to_addr(args.addr))
        impObj = dbgeng.dt_var("acdb24!AcDbImpModelerGeometry", obj.mpImpObject)

        if args.type == "asm" and impObj.mEntityPtr:
            logging.info_ec("Showing ASM ENTITY...")
            c3d_show_asm_entity([hex(impObj.mEntityPtr)])
        else:
            if args.type == "bgc" and impObj.mpBodyGraphicsCache:
                logging.info_ec("Showing BodyGraphicsCache...")
                c3d_show_bgc([hex(impObj.mpBodyGraphicsCache)])
            else:
                if impObj.mEntityPtr:
                    logging.info_ec("Showing ASM ENTITY...")
                    c3d_show_asm_entity([hex(impObj.mEntityPtr)])
                    return

                if impObj.mpBodyGraphicsCache:
                    logging.info_ec("Showing BodyGraphicsCache...")
                    c3d_show_bgc([hex(impObj.mpBodyGraphicsCache)])
                    return

                raise CmdExecError(f"Failed to show object. Neither ASM ENTITY nor BodyGraphicsCache is available.]")


@arg_parser(lambda parser: parser.add_argument("addr", help="the address of the BodyGraphics instance"))
def c3d_show_bgc(args):
    """Show AcModeler::Draw::BodyGraphicsCache geometry according to either name or raw address

    Examples:
        c3d_show_bgc 0x22a20da6780
    """
    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Not a valid address of BodyGraphics. Error: [{errmsg}]")
    else:
        bgc = dbgeng.dt_var("modlr24!AcModeler::Draw::BodyGraphicsCache", dbgeng.to_addr(args.addr))
        center = dbgeng.dt_var("modlr24!AcGePoint3d", bgc.mCenter)
        logging.info_ec(f"Center: {{{float(center.x)}, {float(center.y)}, {float(center.z)}}}")

        payload = {"lines": []}

        def handle_EdgeSet(edge_set, name):
            length = edge_set.mEdgeCaches.mLogicalLen
            logging.info_ec(f"{name} Caches: {int(length)}")
            if not length:
                return length

            mpArray = edge_set.mEdgeCaches.mpArray
            vertices = []
            lines = []

            FETCH_COUNT = 3
            TYPE_SIZE_DOUBLE = 8

            for x in range(length):
                edge = mpArray[x]
                pt_count = edge.mPointCount
                mpData = edge.mpData

                # where the first number denotes the number of points in a line segment and the next two numbers are the indices of those points.
                line = [int(pt_count)]
                for y in range(pt_count):
                    pt_coord = dbgeng.load_doubles(mpData + y * FETCH_COUNT * TYPE_SIZE_DOUBLE, FETCH_COUNT)
                    vertices.append(pt_coord)
                    line.append(len(vertices) - 1)
                lines.append(line)

            payload["lines"].append({"vertices": vertices, "lines": lines})

            return length

        EDGE_BGC_TYPE = "modlr24!AcModeler::Draw::EdgeSetBodyGraphicsCache"
        mFaceEdges = dbgeng.dt_var(EDGE_BGC_TYPE, bgc.mFaceEdges)
        mWireEdges = dbgeng.dt_var(EDGE_BGC_TYPE, bgc.mWireEdges)
        mIsoEdges = dbgeng.dt_var(EDGE_BGC_TYPE, bgc.mIsoEdges)

        count = handle_EdgeSet(mFaceEdges, "mFaceEdges")
        count += handle_EdgeSet(mWireEdges, "mWireEdges")
        count += handle_EdgeSet(mIsoEdges, "mIsoEdges")

        if count:
            path = dump_object(payload)
            if path:
                show_complex_objects(path)
        else:
            logging.warn_ec("Not found any geometry to show EdgeSetBodyGraphicsCache.")


@arg_parser(lambda parser: parser.add_argument("addr", help="the address of the entity"))
def c3d_show_asm_entity(args):
    """Show Autodesk Shape Manager entity

    Examples:
        0:000> [+0x038] mEntityPtr       : 0x1fbed116e88 [Type: ENTITY *]
        0:000> c3d_show_asm_entity 0x1fbed116e88
    """
    is_addr, errmsg = dbgeng.check_valid_addr(args.addr)
    if not is_addr:
        raise CmdExecError(f"Not a valid address of an ASM entity. Error: [{errmsg}]")
    else:
        # asm_entity = dt_var("ASMKERN229A!ENTITY", to_addr(args.addr))
        # asm_entity_data = dt_var("ASMKERN229A!entity_data", asm_entity.m_data_container)
        # log.info(f"Use count : {int(asm_entity_data.m_use_count)}")
        # log.info(f"Bull count: {int(asm_entity_data.m_bull_count)}")
        # log.info(f"Tag no    : {int(asm_entity_data.m_tag_no)}")
        # log.info(f"Status    : {int(asm_entity_data.m_status)}")

        # Body is one of the entities. TODO: handle other entities
        asm_body = dbgeng.dt_var("ASMKERN229A!BODY", dbgeng.to_addr(args.addr))

        vertices = []
        faces = []
        if asm_body.lump_ptr:
            asm_lump = dbgeng.dt_var("ASMKERN229A!LUMP", asm_body.lump_ptr)  # TODO: next lump
            if asm_lump.shell_ptr:
                asm_shell = dbgeng.dt_var("ASMKERN229A!SHELL", asm_lump.shell_ptr)  # TODO: next shell
                if asm_shell.face_ptr:
                    asm_face = dbgeng.dt_var("ASMKERN229A!FACE", asm_shell.face_ptr)  # next face

                    asm_surface = dbgeng.dt_var("ASMKERN229A!SURFACE", asm_face.geometry_ptr)
                    # log.debug(asm_surface)
                    # surface_def = dt_var("ASMKERN229A!plane", asm_surface["def"])
                    # surface_root_point = dt_var("ASMKERN229A!ASM::position", surface_def.root_point)
                    # surface_normal = dt_var("ASMKERN229A!ASM::unit_vector", surface_def.normal)
                    # surface_u_deriv = dt_var("ASMKERN229A!ASM::vector", surface_def.u_deriv)

                    vertex_idx = 0
                    while True:
                        face_pt_indecis_order = []
                        asm_loop = dbgeng.dt_var("ASMKERN229A!LOOP", asm_face.loop_ptr)
                        while True:
                            # fmt: off
                            asm_coedge = dbgeng.dt_var(
                                "ASMKERN229A!COEDGE", asm_loop.start_ptr
                            )
                            first_coedge = asm_coedge
                            while True:
                                asm_edge = dbgeng.dt_var("ASMKERN229A!EDGE", asm_coedge.edge_ptr)

                                start_ptr = dbgeng.dt_var("ASMKERN229A!VERTEX", asm_edge.start_ptr)
                                start_pt = dbgeng.dt_var("ASMKERN229A!APOINT", start_ptr.geometry_ptr)
                                start_pt_coords_data = dbgeng.dt_var("ASMKERN229A!ASM::position", start_pt.coords_data)
                                start_pt_coord = start_pt_coords_data.coord

                                end_ptr = dbgeng.dt_var("ASMKERN229A!VERTEX", asm_edge.end_ptr)
                                end_pt = dbgeng.dt_var("ASMKERN229A!APOINT", end_ptr.geometry_ptr)
                                end_pt_coords_data = dbgeng.dt_var("ASMKERN229A!ASM::position", end_pt.coords_data)
                                end_pt_coord = end_pt_coords_data.coord

                                vertices.append([float(start_pt_coord[0]), float(start_pt_coord[1]), float(start_pt_coord[2])])
                                vertices.append([float(end_pt_coord[0]),float(end_pt_coord[1]),float(end_pt_coord[2])])

                                for _ in range(2):
                                    face_pt_indecis_order.append(vertex_idx)
                                    vertex_idx = vertex_idx + 1

                                if not asm_coedge.next_ptr or asm_coedge.next_ptr == first_coedge:
                                    break

                                asm_coedge = asm_coedge.next_ptr

                            if not asm_loop.next_ptr:
                                break

                            asm_loop = asm_loop.next_ptr
                        # fmt: on

                        face_pt_indices_len = len(face_pt_indecis_order)
                        face_pt_indecis_order.insert(0, face_pt_indices_len)
                        faces.append(face_pt_indecis_order)

                        if not asm_face.next_ptr:
                            break

                        asm_face = asm_face.next_ptr

        path = dump_object({"vertices": vertices, "faces": faces})
        if path:
            show_multiple_faces(path)


@arg_parser(None)
def c3d_show_relgraph(args):
    """Show real graph

    Coming soon...

    Note: There is the bug in Python39\Lib\site-packages\pyvis\network.py. The write_html method should not write the html to current working folder if not local.
    """
    # nxg = nx.complete_graph(5)
    # G = Network()
    # G.from_nx(nxg)

    # G.show_buttons(filter_=["physics"])
    # G.show("demo3.html", False)


"""
Register command at global.
"""
register_ec_command(__file__, c3d_show_ac_polyline)
register_ec_command(__file__, c3d_show_ac_object)
register_ec_command(__file__, c3d_show_bgc)
register_ec_command(__file__, c3d_show_asm_entity)
register_ec_command(__file__, c3d_show_relgraph)
