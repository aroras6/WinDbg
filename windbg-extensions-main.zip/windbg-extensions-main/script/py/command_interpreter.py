"""
It interperts the command which is passed in as arguments and invokes the targeted function.
"""
import argparse
import inspect
import traceback
from functools import partial

from command_common import CmdExecError, ECArgumentParser
from command_register import all_commands
from common import config, consts, logging


class CommandInterpreter:
    def __init__(self, func):
        self.func = func

    def invoke(self, args):
        try:
            self.__preInvoke()

            self.func(args)
        except CmdExecError as e:
            logging.error_ec(e.errmsg)
        except Exception:
            traceback.print_exc()
        finally:
            self.__postInvoke()

    def __preInvoke(self):
        if config.verbose:
            logging.setLevelForAllLoggers(logging.DEBUG)

    def __postInvoke(self):
        if config.verbose:
            logging.resetLevelForAllLoggers()

        # always reset the command verbose flag.
        logging.disable_cmd_verbose()


def invokeCommand(group, cmd, args):
    CommandInterpreter(all_commands[group][cmd]).invoke(args)


def main():
    parser = ECArgumentParser(
        description="Extension Commands for Windbg",
        epilog=inspect.cleandoc(
            f"""        
            For exact command help, try '{consts.WINDBG_EXT_EC} COMMAND help'
            Examples:
                print help of command 'r'
                    !ec r -h

                print help of command 'sc'
                    !ec sc -h
            """
        ),
        usage=f"{consts.WINDBG_EXT_EC} [OPTIONS] COMMAND [ARGS]...",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("-v", "--verbose", action="store_true", help="show more output")
    parser.add_argument("-d", "--debug", action="store_true", help="enable the debugger")
    parser.add_argument("-V", "--version", action="version", version="Extension Commands for Windbg 1.0.4")

    subparsers = parser.add_subparsers(
        title="COMMANDS",
        description=f'Try <link cmd="{consts.WINDBG_EXT_EC} help">{consts.WINDBG_EXT_EC} help</link> to see all available commands',
        metavar="",
    )

    # Register all commands and their real function
    for group in all_commands:
        for cmd in all_commands[group]:
            subcmd = subparsers.add_parser(cmd, add_help=False)
            subcmd.set_defaults(func=partial(invokeCommand, group, cmd))

    args, cmd_args = parser.parse_known_args()

    # Enable verbose
    config.verbose = True if args.verbose else False

    if hasattr(args, "func"):
        # enable the debugger
        if args.debug:
            import web_pdb

            web_pdb.set_trace()

        # run command
        args.func(cmd_args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
