"""
The common utils class.
"""
import os

from utils import LocalShell, LocalShellListener, getWorkingFolder
from urllib.parse import quote


def is_number(n):
    is_number = True
    try:
        num = float(n)
        # check for "nan" floats
        is_number = num == num  # or use `math.isnan(num)`
    except ValueError:
        is_number = False
    return is_number


def check_in_range(val: int, low: int, up: int):
    """Check if low <= val <= up"""
    if low <= val and val <= up:
        return True
    else:
        return False


def show_html(url: str):
    spawnShell(f'start "" chrome.exe --user-data-dir="{getWorkingFolder()}/chrome-user-data-dir" --disable-web-security "{url}"')


def to_html_param(params: dict):
    return "".join([f"{k}={quote(v, safe='') if type(v) is str else v}&" for k, v in params.items()])[:-1]


def getPython():
    return f"{os.path.dirname(os.__file__)}/../python"


def getVirtualEnvCwdRoot():
    """
    Retrieve the current working folder's root folder. The current working folder is the python environment folder.
    """
    path = os.path.dirname(os.path.abspath(__file__))
    return f"{path}/../envs"


def runShell(cmd_line, cwd=None, listener: LocalShellListener = None):
    """
    It executes the shell and waits for the result.
    """
    LocalShell(cmd_line, cwd).run(listener)


def spawnShell(cmd_line, cwd=None):
    """
    It executes the shell and detaches from it.
    """
    LocalShell(cmd_line, cwd).spawn()


def interactShell(cmd_line, cwd=None):
    """
    It executes the shell and enables the interation.
    """
    LocalShell(cmd_line, cwd).interact()


def runPy(cmd_line, env=None, listener: LocalShellListener = None):
    runShell(f"{getPython()} {cmd_line}", f"{getVirtualEnvCwdRoot()}/{env}", listener)


def runPyDetach(cmd_line, env=None):
    spawnShell(f"{getPython()} {cmd_line}", f"{getVirtualEnvCwdRoot()}/{env}")


def runPyInteract(cmd_line, env=None):
    interactShell(f"{getPython()} {cmd_line}", f"{getVirtualEnvCwdRoot()}/{env}")


def runPipenv(cmd_line, env=None, listener: LocalShellListener = None):
    runPy(f"-m pipenv run {cmd_line}", env, listener)


def runPipenvDetach(cmd_line, env=None):
    runPyDetach(f"-m pipenv run {cmd_line}", env)


def runPipenvInteract(cmd_line, env=None):
    runPyInteract(f"-m pipenv run {cmd_line}", env)
