"""
It is the utils of graphic.
"""

from common import consts
from utils import runPipenv, runPipenvDetach, getGraphicFolder


def show_image(payload: str):
    __execute("graphic_image.py", payload)


def show_geodesy_map(payload: str):
    __execute("graphic_geodesy_map.py", payload, env=consts.EC_PYENV_GEODESY)


def execute_geodesy_util_method(payload: str, listener=None):
    __execute("graphic_geodesy_utils.py", payload, env=consts.EC_PYENV_GEODESY, listener=listener)


def show_polyline(payload: str):
    __execute("graphic_polyline.py", payload)


def show_multiple_lines(payload: str):
    __execute("graphic_multiple_lines.py", payload)


def show_multiple_faces(payload: str):
    __execute("graphic_multiple_faces.py", payload)


def show_complex_objects(payload: str):
    __execute("graphic_complex.py", payload)


def __execute(handler: str, payload: str, env: str = consts.EC_PYENV_VISUALIZATION, listener=None):
    """Show graphic by specified handler with the payload.

    Args:
        handler: The py file that deals with the specific payload.
        payload: The file that stores graphic payload.
    """
    cmd_line = f"python {getGraphicFolder()}/{handler} --payload {payload}"

    if listener:
        runPipenv(cmd_line, env, listener)
    else:
        runPipenvDetach(cmd_line, env)
