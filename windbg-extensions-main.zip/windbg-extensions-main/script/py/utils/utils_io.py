"""
It is the utils of file system.
"""
import json
import os
import random
import shutil
import string
from pathlib import Path

from common import config, logging

__logger = logging.getLogger(__name__)


def copyfile(*args, **kwargs):
    shutil.copyfile(*args, **kwargs)


def createfile(file):
    with open(file, "w") as fp:
        pass


def mkdir(cwd):
    Path(cwd).mkdir(parents=True, exist_ok=True)


def pathExists(path):
    __logger.debug(f"Checking if [{path}] exists...")
    return Path(path).exists()


def isDir(path):
    return Path(path).is_dir()


def parentFolder(file):
    return Path(file).parent


def getFile(directory, file):
    __logger.debug(f"Searching [{file}] under folder [{directory}]...")
    if not isDir(directory):
        __logger.debug(f"[{directory}] is not a directory.")
        return None

    for root, dirs, files in os.walk(directory):
        for filename in files:
            if filename == file:
                return os.path.join(root, filename)

    return None


def getRandomFilename(prefix="", suffix=""):
    __logger.debug("Populating random file name...")
    prefix = "ec_tmp_" if not prefix else prefix
    __logger.debug(f"Prefix: {prefix}")

    suffix = f".{suffix}" if suffix else suffix
    __logger.debug(f"Suffix: {suffix}")

    filename = f"{prefix}{''.join(random.choices(string.ascii_letters, k=16))}{suffix}"
    __logger.debug(f"File name: {filename}")
    return filename


def getUserHome():
    home = str(Path.home())
    __logger.debug(f"User home directory: {home}")
    return home


def getWorkingFolder():
    cwd = f"{getUserHome()}\\{config.ec_cwd}"
    mkdir(cwd)
    __logger.debug(f"EC working directory: {cwd}")
    return cwd


def get3rdPartyFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "..", "..", "3rdParty")
    path = os.path.abspath(path)
    __logger.debug(f"EC 3rdParty folder: {path}")

    return path


def getKnowledgeManagementFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "..", "..", "km")
    path = os.path.abspath(path)
    __logger.debug(f"EC knowledge management folder: {path}")

    return path


def getWebResourceFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(path, "..", "web")
    path = os.path.abspath(path)
    __logger.debug(f"EC web resource folder: {path}")

    return path


def getGraphicFolder():
    path = os.path.dirname(os.path.abspath(__file__))
    path = os.path.abspath(f"{path}/../graphic")
    __logger.debug(f"EC graphic folder: {path}")

    return path


def dump_object(obj: list):
    path = f"{getWorkingFolder()}/{getRandomFilename(suffix='json')}"
    try:
        with open(path, "w+") as f:
            json.dump(obj, f)
            __logger.debug(f"Successfully dump the object to [{path}].")
            return path
    except Exception as e:
        __logger.error(f"Failed to dump the object to [{path}], due to [{e}].")
        return None


def load_object(filepath: str):
    try:
        with open(filepath, "r") as f:
            obj = json.load(f)
            __logger.debug(f"Successfully dump the object to [{filepath}].")
            return obj
    except Exception as e:
        __logger.error(f"Failed to dump the object to [{filepath}], due to [{e}].")
        return None
