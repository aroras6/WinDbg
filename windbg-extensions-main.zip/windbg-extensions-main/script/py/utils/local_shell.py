"""
The class that wraps the shell execution.
"""
import os
import subprocess
import sys
import threading
from typing import Callable, Optional

from common import color, logging


class LocalShellListener:
    def __init__(self, res_count: int = 1):
        self.history = []
        self.res_count = res_count

    def listen(self, input):
        self.history.append(input) if self.res_count > 0 else None

    def getResult(self, parser: Callable[[str], tuple[bool, any]]) -> tuple[bool, Optional[any]]:
        """return result when only one is needed, otherwise a list of results"""
        if self.res_count == 0:
            return False, None

        total = len(self.history)
        if total == 0:
            return False, None

        results: list = []

        for line in self.history:
            found, result = parser(line)            
            if found:
                if self.res_count == 1:
                    return True, result
                else:
                    results.append(result)

            total -= 1
            if total < 1:
                break

        return (True, tuple(results)) if len(results) > 0 else (False, None)
    
    def reset(self):
        self.history.clear()


class LocalShell(object):
    def __init__(self, cmd_line, cwd=None):
        self._logger = logging.getLogger(self.__class__.__name__)
        self.cmd_line = cmd_line
        self.cwd = cwd
        self._logger.debug(f"Command line: {cmd_line}")
        self._logger.debug(f"CWD: {cwd}")

    def run(self, listener: LocalShellListener = None):
        """
        Run the shell and waits for the shell to be finished.
        """
        env = os.environ.copy()
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        process = subprocess.Popen(
            self.cmd_line,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=si,
            env=env,
            cwd=self.cwd,
            shell=True,
            encoding="utf-8",
            errors="replace",
        )

        while process.poll() is None:
            data = process.stdout.readline()
            if data and data.strip():
                logging.info_ec(data, False if data.endswith(("\n", "\r", "\r\n")) else True)
                if listener:
                    listener.listen(data.strip())

    def spawn(self):
        """
        Spawn the process and detach from it.
        """
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        subprocess.Popen(self.cmd_line, startupinfo=si, cwd=self.cwd, shell=True)

    def interact(self):
        """
        Run the shell and allows the interaction.
        """
        self._logger.debug("Starting local terminal...")
        logging.info_ec(color.purple("Use 'exit' to terminate the shell!!!"))

        env = os.environ.copy()
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        process = subprocess.Popen(
            self.cmd_line,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            startupinfo=si,
            env=env,
            cwd=self.cwd,
            shell=True,
            encoding="utf-8",
            errors="replace",
        )

        def pull(p: subprocess.Popen):
            self._logger.debug("Starting pull thread...")
            while True:
                try:
                    data: str = p.stdout.readline()
                    if data and data.strip():
                        logging.info_ec(data, False if data.endswith(("\n", "\r", "\r\n")) else True)
                    else:
                        if not data:
                            self._logger.warning('shell seems to be closed. Run "exit" to finish the push thread!')
                            break
                except ValueError as e:
                    # The pipe might be closed. The termination is to close stdin/stdout pipes.
                    self._logger.debug(f"Failed to run pull thread. Reason: {e}")
                    break
                except:
                    self._logger.error(f"Error: {str(sys.exc_info()[1])}")
                    break
            self._logger.debug("Terminated pull thread.")

        puller = threading.Thread(target=pull, args=(process,))
        puller.start()

        def push(p: subprocess.Popen):
            self._logger.debug("Starting push thread...")
            while True:
                try:
                    input = sys.stdin.readline()
                    if input == "exit":
                        # Close the pipe
                        out, err_ = p.communicate()
                        logging.info_ec(out)
                        if err_:
                            self._logger.error(err_)
                        break
                    if input and input.strip():
                        p.stdin.write(input + "\n")
                        p.stdin.flush()
                except:
                    self._logger.error(f"Error: {str(sys.exc_info()[1])}")
            self._logger.debug("Terminated push thread.")

        pusher = threading.Thread(target=push, args=(process,))
        pusher.start()
