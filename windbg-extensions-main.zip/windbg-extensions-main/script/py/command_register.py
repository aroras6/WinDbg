"""
It automatically creates Windbg aliases for the extensions.

The alias triggers the real command by passing it to command interpreter.
"""
import os
from argparse import Namespace
from typing import Callable, Union

from common import dbgeng
from utils import *

# This dictionary should be declared before all commands import, since the commands also need to refer to it.
all_commands: dict[str, dict[str, Callable[[Union[list[str], Namespace]], None]]] = {}


def register_ec_command(group: object, cmd: object):
    groupName = os.path.splitext(os.path.basename(group))[0].replace("cmd_", "")
    cmdGroup = all_commands.setdefault(groupName, {})
    cmdGroup[cmd.__name__] = cmd


def retrieve_ec_command(cmd_name: str):
    for _, cmds in all_commands:
        for cmd in cmds:
            if cmd == cmd_name:
                return cmds[cmd]

    return None


# Import all commands. cmd_help is special and should not be the last one.
import cmds.cmd_basic
import cmds.cmd_c3d
import cmds.cmd_dump
import cmds.cmd_exploit
import cmds.cmd_geodesy
import cmds.cmd_help
import cmds.cmd_knowledge
import cmds.cmd_pe
import cmds.cmd_utility


# Register Windbg commands as alias.
def register_ec(cmd):
    path = os.path.dirname(os.path.abspath(__file__))
    dbgeng.set_alias(cmd, f"!py -g {path}\command_interpreter.py")


def register_mona(cmd):
    path = get3rdPartyFolder()
    cwd = getWorkingFolder()

    cwd_mona = f"{cwd}\mona"
    mkdir(cwd_mona)

    try:
        mona_path = f"{cwd_mona}\mona.py"
        if not pathExists(mona_path):
            copyfile(f"{path}\mona\mona.py", mona_path)

        windbglib_path = f"{cwd_mona}\windbglib.py"
        if not pathExists(windbglib_path):
            copyfile(f"{path}\windbglib\windbglib.py", windbglib_path)

        # Run mona by Python 2.7
        dbgeng.set_alias(cmd, f"!py -2 {mona_path}")
    except:
        logging.warn_ec("Failed to register mona!")
