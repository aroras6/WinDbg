# Extension Commands for Windbg
The Python scripts for extending Windbg capabilites. 

## Overivew
Extension Commands for Windbg (aka EC) is the Windbg extension written in Python. It aims to extend Windbg capabilities by a bunch of Python scripts.

EC leverages pykd, hence 3rdParty Python open source libraries are able to be integrated for different puropses, such as visualization, processing the data, etc.

EC is also implemented as a framework that allows the commands to be registered in a convenience way. Now, there are commands for common purposes and commands for specific products, e.g., Civil3D, CsMap, etc.

## Quick start
1. Install Python `3.9.13`. Note: this is the latest 3.x version that has pykd spport.
2. Install Python `2.7.18`. Note: this is the latest 2.x version that has pykd support
3. Install pykd in Python `2.7.18` and `3.9.13` respectively. e.g. `py -3.9 -m pip install pykd` and `py -2.7 -m pip install pykd`. Note: If you get `No module named pip` error, install it manually by downloading the `get-pip.py` first, i.e. `curl https://bootstrap.pypa.io/pip/2.7/get-pip.py --output get-pip.py`, then run `py -2.7 get-pip.py`. Note: Python Launcher (py) is available once you have Python install.
4. Load Windbg extension named `pykd` in Windbg, i.e. `.load path\to\pykd`. Note: it is available in this project named `pykd.dll`.
5. Make sure `!py -h` is valid in Windbg. You will see the !py help text.
6. Make sure Python `3.9` is the selected interpreter.
    ```
    0:001> !info

    pykd bootstrapper version: 2.0.0.25

    Installed python:

    Version:        Status:     Image:
    ------------------------------------------------------------------------------
    2.7 x86-64    Loaded      C:\Windows\SYSTEM32\python27.dll
    * 3.9 x86-64    Loaded      C:\Users\wuol\AppData\Local\Programs\Python\Python39\python39.dll
    3.11 x86-64   Unloaded    C:\Users\wuol\AppData\Local\Programs\Python\Python311\python311.dll
    ```
7. Load EC by running `!py -g path\to\ec.py` and you will see the welcome as below.
    ```
    Successfully loaded Extension Commands for Windbg! Run [!ec help] for more details.
    ```
8. In order to use some 3rdParty tools, go to `envs` folder, and setup Python virtual enviroments for them respectively. e.g.
    ```
    cd minidump
    py -m pipenv install
    ```
    Note: for such tools, the Python working folder is the virtual environment root, e.g. `envs\minidump`.

## Usage
After launching the EC in Windbg, its current working folder is switched to `.windbg_ec` under user home.

For EC usage, try `!ec -h`. For EC available commands, try `!ec help`.

Some graphic functionalities that depend on PyVista can be rendered in different ways. By default, it is PyVista plotter. You can specify either Panel server or Panel HTML as well. For example:
```
usage: graphic_polyline.py [-h] [--payload PAYLOAD] [--renderer [{0,1,2}]]
Note: The script should be run at the 'envs\visualization' folder.
```

## Development
### Virtual Environment
Since the virtual environment is used for isolating Python runtime enviroment, when developing specific feature, the corresponding virtual environment should be switched for convenience. VSCode allows to switch to specific Python interpretor at the right bottom bar if you have the corresponding extensions installed.

### Graphic
EC is able to dump the 3D geometries to local temp folder and leverage Python visualization tools, e.g., PyVista, for rendering. Note: since pykd is a Windbg extension, trigger such visualization tools causes Windbg window hang. This is the reason that we dump the payload to local disk, and spawn a new Python process for dealing with the payload.

The `graphic` folder maintains the logic for handling different kinds of the geometries. The logic should not import any module of this framework except for consts class, so that it can be opened by Python standalone.

### Logging
There are 2 types of logging, one is leveraging Python logging which can be used for debuging and troubleshooting, and the other writes the message directly to Windbg console. The latter one is for command output.

The former one:
```
logger = logging.getLogger(self.__class__.__name__)
logger.info(...)
logger.debug(...)
```

The latter one:
```
logger.info_ec(...)
logger.debug_ec(...)
```

### Formatter
Black is recommanded for formatting the python code. The Prettier is recommanded for formatting other files. The configuration in vscode `settings.json` is as below:

```
"python.defaultInterpreterPath": "C:\\Users\\wuol\\AppData\\Local\\Programs\\Python\\Python39",
"python.formatting.provider": "black",
"python.formatting.blackArgs": [
    "--line-length",
    "160",
    "--target-version",
    "py39"
    // "--lint", "pylint"
],
"python.analysis.typeCheckingMode": "off",
"prettier.useEditorConfig": false,
"prettier.useTabs": false,
"prettier.configPath": ".prettierrc"
```

### Debugging
The pdb can be used for pykd in Windbg. More convenient way is to have a debugger gui. Unfortunately, Mircosoft debugpy doesn't seem to work well in Windbg, hence we choose the [web-pdb](https://github.com/romanvm/python-web-pdb). 

Install the `web-pdb` in `python39` that runs pykd.
```
py -m pip install web-pdb
```
Then, when executing specific command, add `-d` argument, e.g.,
```
!ec -d cwd
```
You will see a reminder for opening browser with specific url.
```
CRITICAL - root - __init__ - Web-PDB: starting web-server on SHAPC2L06XG:5555...
```
Within the browser, all `pdb` commands are available. For example, you can add breakpoint like `b cmds\\cmd_utility:15`. you can remove all breakpoints by `cl` (Note: the hint is printed in Windbg input, so, you have to enter Y/N there for pdb to continue executing).

Remember to finish the execution and `web-pdb` server stops. Close the browser without finish the execution causes Windbg input waiting forever. In case that, open the browser again, and finish the execution.
```
CRITICAL - root - close - Web-PDB: stopping web-server...
CRITICAL - root - close - Web-PDB: web-server stopped.
```

EC command `-d` argument automatically sets breakpoint for you. Alternatively, you can add `import web_pdb; web_pdb.set_trace()` to any place you want to start debugging.

## License
[MIT](../../LICENSE)

## References
* [pykd API Reference](https://githomelab.ru/pykd/pykd/-/wikis/API%20Reference)
* [PyVista API Reference](https://docs.pyvista.org/api/)
* [Jupyter Notebook](https://jupyter.org/)
* [argparse API Reference](https://docs.python.org/3/library/argparse.html)
* [mona](https://github.com/corelan/mona)
* [cesiumjs](https://cesium.com/platform/cesiumjs/)
* [cesiumjs](https://cesium.com/platform/cesiumjs/)
* [cartopy](https://scitools.org.uk/cartopy/)


## Dependencies
| Name                       | License           | Vendored Version  |
| ---------------------------| ----------------- | ------------------|
| [minidump](https://github.com/skelsec/minidump)               | MIT        | 0.0.21        |
| [pe-tree](https://github.com/blackberry/pe_tree)              | Apache-2.0        | 1.0.29        |
| [Volatility3](https://github.com/volatilityfoundation/volatility3)              | Copyright (C) 2007-2022 Volatility Foundation        | 3.2.4.0        |
| [mona](https://github.com/corelan/mona)              | BSD-3-Clause        | unknown        |
| [windbglib](https://github.com/corelan/windbglib)              | BSD-3-Clause        | unknown        |
| [pykd](https://githomelab.ru/pykd/pykd)              | MIT        | 0.3.4.15        |
| [argparse](https://github.com/ThomasWaldmann/argparse/)              | Python Software Foundation License        | 1.4.0        |
| [PyVista](https://github.com/PyVista)              | MIT        | 0.38.2        |
| [pipenv](https://github.com/pypa/pipenv)              | MIT        | v2023.2.4        |
| [cesiumjs](https://github.com/CesiumGS/cesium)              | Apache-2.0        | 1.103        |
| [cartopy](https://github.com/SciTools/cartopy)              | LGPL-3.0, GPL-3.0 licenses        | 0.20.2        |

## Acknowledgement
* [TWindbg](https://github.com/bruce30262/TWindbg)