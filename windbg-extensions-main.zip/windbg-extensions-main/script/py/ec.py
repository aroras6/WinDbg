"""
Extension Commands for Windbg.

This is an extension of Windbg, leveraging pykd. It provides a bunch of convenient commands for debugging and troubleshooting.

Usage:
    !py -g path/to/ec.py

Note:
    1. The argument '-g' is for sharing the !py common namespace.
    2. This extension should be run in Python 3.
"""
import os
import sys

from common import logging

# It causes the specific module to be reloaded. Run this ec.py again to take effect.
# It is for development purpose, so that you don't need to restart Windbg. Note: it not always work.
modulesToDelete = []
for m in sys.modules:
    moduleName = str(m)
    # Following module will not be removed.
    if moduleName in ["common.log"]:
        continue
    # Remove logging as well, since its root logger is cached and shared.
    for k in ["command_", "cmds.", "common.", "graphic.", "utils"]:
        if k in moduleName:
            modulesToDelete.append(moduleName)
            break
currentModule = __name__
for mod in modulesToDelete:
    if mod != currentModule:  # Python cannot delete the current module
        logging.debug_ec(f"Removing Python module {mod} ...")
        del sys.modules[mod]

from command_register import *
from common import consts, context
from utils import *


def main():
    # Initiate debugging context, such as registers, cpu arch, etc.
    context.init_arch()
    context.init_context_handler()

    # Set working folder
    os.chdir(getWorkingFolder())

    # Register Windbg commands of this extension.
    register_ec(consts.WINDBG_EXT_EC)
    register_mona(consts.WINDBG_EXT_MONA)

    prompt = f'Successfully loaded Extension Commands for Windbg! Run [<link cmd="{consts.WINDBG_EXT_EC} help">{consts.WINDBG_EXT_EC} help</link>] for more details.'    
    logging.info_ec(prompt)


if __name__ == "__main__":
    main()
