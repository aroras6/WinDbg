import numpy as np
import pyvista as pv
from graphic_common_mesh import draw_mesh


def mesh_resolver(payload):
    vertices = np.array(payload["vertices"])
    lines = np.hstack(payload["lines"])

    mesh = pv.PolyData(vertices, lines=lines)
    return mesh


if __name__ == "__main__":
    draw_mesh(mesh_resolver)
