import pyvista as pv
from graphic_common_mesh import draw_mesh


def mesh_resolver(payload):
    mesh = pv.MultipleLines(payload)
    return mesh


if __name__ == "__main__":
    draw_mesh(mesh_resolver)
