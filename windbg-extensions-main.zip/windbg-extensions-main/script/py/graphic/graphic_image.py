import argparse

import matplotlib.image as mpimg
import matplotlib.pyplot as plt

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Show an image")
    parser.add_argument("--payload", type=str, help="The image path")

    args = parser.parse_args()

    plt.imshow(mpimg.imread(args.payload))
    plt.axis("off")
    plt.show()
