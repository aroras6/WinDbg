import numpy as np
import pyvista as pv
from graphic_common_mesh import draw_mesh


def mesh_resolver(payload):
    vertices = np.array(payload["vertices"])
    faces = np.hstack(payload["faces"])

    mesh = pv.PolyData(vertices, faces)
    return mesh


if __name__ == "__main__":
    draw_mesh(mesh_resolver)
