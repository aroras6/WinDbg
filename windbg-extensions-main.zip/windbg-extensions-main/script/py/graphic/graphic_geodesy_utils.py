# This utils depends on some packages that hang the Windbg. So, don't now run within pykd.

import argparse
import math

from scipy.spatial.transform import Rotation as R
import numpy as np
from graphic_common import ParseKwargs

__RADIANS_PER_ARCSECOND = 0.00000484813681109536

def calculateTranslationRotationMatrix(v1, v2):
     # Calculate the cross product of the input vectors
    w = np.cross(v1, v2)

    # Normalize the input vectors and the orthogonal vector
    u1 = v1 / np.linalg.norm(v1)
    u2 = v2 / np.linalg.norm(v2)
    u3 = w / np.linalg.norm(w)

    # Construct the rotation matrix
    R = np.column_stack((u1, u2, u3)).T
    return R


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Geodesy utils.")
    parser.add_argument("--payload", nargs="*", action=ParseKwargs, help="The payload of invoking a method name.")

    args = parser.parse_args()

    payload = args.payload

    if payload["name"] == "calculateRotationEulerAngles":
        Oab = [float(e) for e in payload["Oab"].split(",")]
        Pxb = [float(e) for e in payload["Pxb"].split(",")]
        Pyb = [float(e) for e in payload["Pyb"].split(",")]

        Oab = np.array(Oab)
        Pxb = np.array(Pxb)
        Pyb = np.array(Pyb)

        Rab = calculateTranslationRotationMatrix(Pxb - Oab, Pyb - Oab)
        
        rotation = R.from_matrix(Rab)
        euler = rotation.as_euler('xyz')
        print(euler/__RADIANS_PER_ARCSECOND)
