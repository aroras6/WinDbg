import numpy as np
import pyvista as pv
from graphic_common_mesh import draw_mesh


def mesh_resolver(payload):
    """
    The payload looks like: {"lines": [], "faces": []}
    """

    # Handle lines
    payload_lines = payload["lines"]
    for payload_line in payload_lines:
        vertices = np.array(payload_line["vertices"])
        lines = np.hstack(payload_line["lines"])
        mesh = pv.PolyData(vertices, lines=lines)
        return mesh

    return None


if __name__ == "__main__":
    draw_mesh(mesh_resolver)
