# Major Visualizers
| | | | | |
|---|---|---|---|---|
| [AcDbStub](#acdbstub) | [AcDbObjectId](#acdbobjectid) | [AcCmEntityColor](#accmentitycolor) | [AcDbEntity](#acdbentity) | |
| [AeccAttribute](#aeccattribute) | [AeccAtom](#aeccatom) | |  | |
| [QUrl](#qurl) | | | | |

# AcDbStub
## [Back to Top](#major-visualizers)
| ![](./images/AcDbStub-before.png) | ![](./images/AcDbStub-after.png) |
|:---:|:---:|
| Before | After |

# AcDbObjectId
## [Back to Top](#major-visualizers)
| ![](./images/AcDbObjectId-before.png) | ![](./images/AcDbObjectId-after.png) |
|:---:|:---:|
| Before | After |

# AcCmEntityColor
## [Back to Top](#major-visualizers)
| ![](./images/AcCmEntityColor-before.png) | ![](./images/AcCmEntityColor-after.png) |
|:---:|:---:|
| Before | After |

# AcDbEntity
## [Back to Top](#major-visualizers)
| ![](./images/AcDbEntity-before.png) | ![](./images/AcDbEntity-after.png) |
|:---:|:---:|
| Before | After |

# AeccAttribute
## [Back to Top](#major-visualizers)
| ![](./images/AeccAttribute-before.png) | ![](./images/AeccAttribute-after.png) |
|:---:|:---:|
| Before | After |

# AeccAtom
## [Back to Top](#major-visualizers)
| ![](./images/AeccAtom-before.png) | ![](./images/AeccAtom-after.png) |
|:---:|:---:|
| Before | After |

# QUrl
## [Back to Top](#major-visualizers)
| ![](./images/qurl-before.png) | ![](./images/qurl-after.png) |
|:---:|:---:|
| Before | After |

