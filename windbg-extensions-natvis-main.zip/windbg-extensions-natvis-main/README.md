# windbg-extensions-natvis
The natvis visualizers. This is an incubation repository. Once the specific natvis is ready, it will be moved to corresponding projects.

## Usage
Load the natvis file by running the following command:
```
.nvload <path of the .natvis file>
```

Alternatively, you can generate all-in-one natvis file by running the following command:
```powershell
.\Scripts\combine_natvis.ps1
```
Note: If you encounter the error "Execution of scripts is disabled on this system.", run `powershell -ExecutionPolicy Bypass -File .\Scripts\combine_natvis.ps1`.

## Supported Visualizers
[Visualizers](./Doc/visualizers.md)

## License
[MIT](../../LICENSE)
