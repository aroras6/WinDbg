param (
    [Parameter(Mandatory=$false)][string]$origword,
    [Parameter(Mandatory=$false)][string]$targetword
)

# Get a list of all files in the current directory
$files = Get-ChildItem -File

# Display the list of files to the user and ask them to select one for input
$i = 1
Write-Host "Select an input file:"
foreach ($file in $files) {
    Write-Host "$i. $($file.Name)"
    $i++
}
$selected = Read-Host -Prompt "Enter the number of the input file"
$filepath = $files[$selected - 1].FullName

# Reset the counter and display the list of files to the user again, asking them to select one for output
$i = 1
Write-Host "Select an output file:"
foreach ($file in $files) {
    Write-Host "$i. $($file.Name)"
    $i++
}
$selected = Read-Host -Prompt "Enter the number of the output file or type the full path of a file"

# Check if the input is an integer. If it is, get the file from the list. If not, treat it as a file path.
if ($selected -as [int]) {
    $outputpath = $files[$selected - 1].FullName
} else {
    $outputpath = $selected
}

# If original word is not provided, prompt the user to enter it
if(-not $origword) {
    $origword = Read-Host -Prompt "Enter the word to be replaced"
}

# If target word is not provided, prompt the user to enter it
if(-not $targetword) {
    $targetword = Read-Host -Prompt "Enter the replacement word"
}

# Perform the word replacement operation and write the output to the selected output file
(Get-Content $filepath) |
Foreach-Object {$_ -replace $origword, $targetword} |
Set-Content $outputpath
