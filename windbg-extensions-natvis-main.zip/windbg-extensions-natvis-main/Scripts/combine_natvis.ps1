# Prompt for the folder path
$FolderPath = Read-Host -Prompt 'Enter the folder path relative to the current working folder (press enter for current folder)'

# If no folder path is provided, use the current working directory
if([string]::IsNullOrWhiteSpace($FolderPath)) {
    $FolderPath = Get-Location
}
else {
    # Resolve the relative path to an absolute path
    $FolderPath = Resolve-Path $FolderPath
}

# Define the output file path
$OutputFilePath = Join-Path -Path $FolderPath -ChildPath 'all-in-one.natvis'

# If 'all-in-one.natvis' file exists, delete it
if(Test-Path $OutputFilePath) {
    Remove-Item $OutputFilePath
}

# Create an empty XML document with the root element
[xml]$CombinedNatvis = @"
<AutoVisualizer xmlns="http://schemas.microsoft.com/vstudio/debugger/natvis/2010">
</AutoVisualizer>
"@

# Get all natvis files from the folder
$Files = Get-ChildItem -Path $FolderPath -Filter *.natvis

foreach($File in $Files){
    Write-Output "Combining $File"

    # Load each natvis file
    [xml]$Natvis = Get-Content $File.FullName

    # Import nodes from each natvis file to the combined natvis
    foreach($Node in $Natvis.AutoVisualizer.ChildNodes){
        $ImportedNode = $CombinedNatvis.ImportNode($Node, $true)
        $CombinedNatvis.AutoVisualizer.AppendChild($ImportedNode) | Out-Null
    }
}

# Save the combined natvis to a file
$CombinedNatvis.OuterXml | Set-Content -Path $OutputFilePath

# Print the location of the combined natvis file
Write-Output "The combined natvis file is located at: $OutputFilePath"
