# windbg-extensions-cmdtree
It maintains a bunch of cmdtrees of Windbg. The Windbg `.cmdtree` command allows to open a .txt file with predefined commands which you can simply double click to execute.

## Usage
```
.cmdtree <path of the main.txt file>
```

## License
[MIT](../../LICENSE)    